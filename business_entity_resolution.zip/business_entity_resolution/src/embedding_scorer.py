"""
Multilingual Embedding Feature Scorer.
Uses paraphrase-multilingual-MiniLM-L12-v2 (118M params, MIT License, <8B constraint OK)
to compute semantic cosine similarity between candidate pairs.

Key design:
- Encodes S1 records once upfront, in batch.
- Encodes only unique candidate S2/S3 records (not all 10M) to stay tractable on CPU.
- Computes cosine similarity per candidate pair as an additional scoring feature.
- Specifically designed to bridge cross-script gaps (English <-> Devanagari/Tamil).
"""

import sys
import time
import numpy as np
from collections import defaultdict

try:
    from .normalize import normalize_name, normalize_address, STOPWORDS
except ImportError:
    from src.normalize import normalize_name, normalize_address, STOPWORDS


def build_embedding_text(name: str, addr: str) -> str:
    """
    Creates a combined semantic text for embedding.
    Uses raw name (NOT normalized) to preserve script information for cross-lingual alignment.
    Adds key address tokens for spatial anchoring.
    """
    _, _, addr_clean, addr_nums = _get_addr_parts(addr)
    # Use raw name for script-preserving semantics
    name_part = name.strip()
    addr_part = ' '.join(addr_nums[:2])  # Just numbers for spatial anchor
    return f"{name_part} {addr_part}".strip() if addr_part else name_part


def _get_addr_parts(addr: str):
    from src.normalize import normalize_address
    addr_clean, addr_words, addr_nums = normalize_address(addr)
    return addr_clean, addr_words, addr_nums, addr_nums


class MultilingualEmbeddingScorer:
    """
    Computes multilingual semantic similarity scores for candidate pairs.
    """
    def __init__(self, model_name: str = 'paraphrase-multilingual-MiniLM-L12-v2', batch_size: int = 512):
        self.model_name = model_name
        self.batch_size = batch_size
        self._model = None
        self.s1_embeddings = {}     # s1_id -> embedding vector
        self.cand_embeddings = {}   # cand_id -> embedding vector

    @property
    def model(self):
        if self._model is None:
            from sentence_transformers import SentenceTransformer
            import os
            os.environ['HF_HUB_DISABLE_SYMLINKS_WARNING'] = '1'
            self._model = SentenceTransformer(self.model_name)
        return self._model

    def encode_s1_records(self, s1_records: list[tuple[str, str, str]]):
        """
        Batch-encode all S1 reference records.
        s1_records: list of (s1_id, name, addr)
        """
        t0 = time.time()
        ids = [r[0] for r in s1_records]
        texts = [build_embedding_text(r[1], r[2]) for r in s1_records]
        
        embeddings = self.model.encode(
            texts,
            batch_size=self.batch_size,
            show_progress_bar=True,
            convert_to_numpy=True,
            normalize_embeddings=True  # L2 normalize for cosine via dot product
        )
        
        for i, s1_id in enumerate(ids):
            self.s1_embeddings[s1_id] = embeddings[i]
        
        print(f"[Embeddings] Encoded {len(ids):,} S1 records in {time.time()-t0:.1f}s")

    def encode_candidate_records(self, cand_records: list[tuple[str, str, str]]):
        """
        Batch-encode unique candidate records from S2/S3.
        cand_records: list of (cand_id, name, addr)
        """
        # Only encode records not already encoded
        new_records = [(eid, name, addr) for eid, name, addr in cand_records if eid not in self.cand_embeddings]
        if not new_records:
            return
        
        t0 = time.time()
        ids = [r[0] for r in new_records]
        texts = [build_embedding_text(r[1], r[2]) for r in new_records]
        
        embeddings = self.model.encode(
            texts,
            batch_size=self.batch_size,
            show_progress_bar=len(ids) > 100000,
            convert_to_numpy=True,
            normalize_embeddings=True
        )
        
        for i, eid in enumerate(ids):
            self.cand_embeddings[eid] = embeddings[i]
        
        print(f"[Embeddings] Encoded {len(ids):,} candidate records in {time.time()-t0:.1f}s")

    def get_similarity(self, s1_id: str, cand_id: str) -> float:
        """
        Returns cosine similarity between S1 and candidate embeddings.
        Returns 0.0 if either embedding is missing.
        """
        s1_emb = self.s1_embeddings.get(s1_id)
        cand_emb = self.cand_embeddings.get(cand_id)
        if s1_emb is None or cand_emb is None:
            return 0.0
        # Both normalized -> dot product = cosine similarity
        return float(np.dot(s1_emb, cand_emb))

    def get_similarity_batch(self, s1_id: str, cand_ids: list[str]) -> list[float]:
        """
        Returns cosine similarity scores for one S1 against multiple candidates.
        """
        s1_emb = self.s1_embeddings.get(s1_id)
        if s1_emb is None:
            return [0.0] * len(cand_ids)
        
        result = []
        for cand_id in cand_ids:
            cand_emb = self.cand_embeddings.get(cand_id)
            if cand_emb is None:
                result.append(0.0)
            else:
                result.append(float(np.dot(s1_emb, cand_emb)))
        return result
