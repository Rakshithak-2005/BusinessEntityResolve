"""
Candidate Generation and Blocking Engine (Enhanced V2).
Builds a multi-facet compound inverted index:
1. Lexical Name Keys (Full, 2-token prefix, sorted tokens, compact alphanumeric)
2. Phonetic Soundex Anchors (Soundex of brand token + building/plot number)
3. Structural Geospatial Anchors (Building number + street/locality words)
4. Cross-Field Locality Anchors (Brand token + city/state token)
5. Character 3-Gram Stems (Typo and OCR resilience)
"""

from collections import defaultdict
try:
    from .normalize import (
        normalize_name, normalize_address, STOPWORDS, LEGAL_SUFFIXES,
        soundex, extract_char_3grams, is_indic_non_ascii
    )
except ImportError:
    from src.normalize import (
        normalize_name, normalize_address, STOPWORDS, LEGAL_SUFFIXES,
        soundex, extract_char_3grams, is_indic_non_ascii
    )


def extract_blocking_keys(name: str, address: str) -> list[tuple[str, str]]:
    """
    Extracts high-selectivity multi-facet compound blocking keys.
    """
    _, name_tokens = normalize_name(name)
    _, addr_words, addr_nums = normalize_address(address)
    
    clean_name_tokens = [w for w in name_tokens if w not in STOPWORDS and len(w) >= 2]
    clean_addr_words = [w for w in addr_words if w not in STOPWORDS and len(w) >= 3]

    keys = []

    # 1. Full cleaned name key (up to 3 words)
    if clean_name_tokens:
        keys.append(('NFULL', '_'.join(clean_name_tokens[:3])))

    # 2. 2-token prefix and sorted tokens (high selectivity)
    if len(clean_name_tokens) >= 2:
        keys.append(('N2', f"{clean_name_tokens[0]}_{clean_name_tokens[1]}"))
        keys.append(('NSORT', '_'.join(sorted(clean_name_tokens[:2]))))
    elif len(clean_name_tokens) == 1 and len(clean_name_tokens[0]) >= 4:
        keys.append(('N1', clean_name_tokens[0]))

    # 3. Compact prefix (joined alpha chars)
    compact = ''.join(clean_name_tokens)
    if len(compact) >= 5:
        keys.append(('NCOMPACT', compact[:7]))

    # 4. Phonetic Anchor: Soundex(brand_word) + Building/Door Number
    if clean_name_tokens and addr_nums:
        snd = soundex(clean_name_tokens[0])
        if snd:
            keys.append(('PHON_ADDR', f"{snd}_{addr_nums[0]}"))

    # 5. Compound: Name token + Address Number (High Precision Anchor!)
    if clean_name_tokens and addr_nums:
        keys.append(('NAME_NUM', f"{clean_name_tokens[0]}_{addr_nums[0]}"))

    # 6. Address Anchors: Building/Plot Number + Street / Locality Words
    if addr_nums and clean_addr_words:
        keys.append(('ADDR_ANCHOR', f"{addr_nums[0]}_{clean_addr_words[0]}"))
        if len(clean_addr_words) >= 2:
            keys.append(('ADDR_ANCHOR2', f"{addr_nums[0]}_{clean_addr_words[1]}"))
        # Plot number + last address word (typically City or State)
        if len(clean_addr_words) >= 3:
            keys.append(('ADDR_CITY', f"{addr_nums[0]}_{clean_addr_words[-1]}"))

    # 7. Brand Token + City/Locality (for single-word or short names)
    if clean_name_tokens and clean_addr_words:
        keys.append(('NAME_CITY', f"{clean_name_tokens[0]}_{clean_addr_words[-1]}"))

    # 8. Character 3-Gram Stems for short/typo names
    if clean_name_tokens and len(clean_name_tokens[0]) >= 5:
        grams = extract_char_3grams(clean_name_tokens[0], max_grams=2)
        for g in grams:
            if addr_nums:
                keys.append(('GRAM_NUM', f"{g}_{addr_nums[0]}"))

    return keys


class BlockingIndex:
    """
    Inverted index storing entity IDs under blocking keys with frequency pruning.
    """
    def __init__(self, max_bucket_size: int = 50):
        self.max_bucket_size = max_bucket_size
        self.index = defaultdict(list)

    def add(self, entity_id: str, keys: list[tuple[str, str]]):
        for ktype, kval in keys:
            bucket = self.index[(ktype, kval)]
            if len(bucket) < self.max_bucket_size:
                bucket.append(entity_id)

    def get_candidates(self, keys: list[tuple[str, str]], max_cands: int = 40) -> set[str]:
        candidates = set()
        for ktype, kval in keys:
            bucket = self.index.get((ktype, kval))
            if bucket and len(bucket) <= self.max_bucket_size:
                for eid in bucket:
                    candidates.add(eid)
                    if len(candidates) >= max_cands:
                        return candidates
        return candidates
