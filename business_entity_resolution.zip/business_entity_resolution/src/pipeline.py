"""
Production End-to-End Entity Resolution Pipeline.
M-RESOLVER Architecture:
- Full-scale streaming candidate generation and real-time C++ RapidFuzz scoring
- Unified single-pass stream across test_source2.tsv and test_source3.tsv
- Country-stratified index lookup (zero cross-country false positives)
- Dynamic frequency pruning to prevent bucket explosion
- Streaming top-K min-heap candidate budgeting
- Precision-weighted threshold gating for Macro F_0.5 optimization
- Direct generation and export of matching_results.tsv and candidate_pairs.tsv
"""

import csv
import sys
import os
import time
import heapq
from collections import defaultdict
from rapidfuzz import fuzz

try:
    from .normalize import normalize_name, normalize_address, STOPWORDS, LEGAL_SUFFIXES
except ImportError:
    from src.normalize import normalize_name, normalize_address, STOPWORDS, LEGAL_SUFFIXES

sys.stdout.reconfigure(encoding='utf-8')

# Number of candidates retained per Source 1 entity for inference
TOP_K_CANDIDATES = 15

# Calibrated decision threshold optimizing Macro F_0.5
MATCH_THRESHOLD = 78.0

# Admission threshold to enter the candidate min-heap
CANDIDATE_ADMISSION_THRESHOLD = 48.0

# Maximum size of an inverted index bucket before pruning
MAX_BUCKET_SIZE = 40


def extract_record_keys(name: str, addr: str) -> tuple[str, list[str], str, list[str], list[tuple[str, str]]]:
    """
    Normalizes record text and extracts multi-facet compound blocking keys.
    """
    name_clean, name_toks = normalize_name(name)
    addr_clean, addr_words, addr_nums = normalize_address(addr)

    clean_n_toks = [w for w in name_toks if w not in STOPWORDS and len(w) >= 2]
    clean_a_words = [w for w in addr_words if w not in STOPWORDS and len(w) >= 3]

    keys = []
    
    # 1. Cleaned full name key (first 3 content tokens)
    if clean_n_toks:
        keys.append(('NFULL', '_'.join(clean_n_toks[:3])))

    # 2. 2-token prefix and sorted tokens (high selectivity)
    if len(clean_n_toks) >= 2:
        keys.append(('N2', f"{clean_n_toks[0]}_{clean_n_toks[1]}"))
        keys.append(('NSORT', '_'.join(sorted(clean_n_toks[:2]))))
    elif len(clean_n_toks) == 1 and len(clean_n_toks[0]) >= 4:
        keys.append(('N1', clean_n_toks[0]))

    # 3. Compact alphanumeric prefix (joined alpha chars)
    compact = ''.join(clean_n_toks)
    if len(compact) >= 5:
        keys.append(('NCOMPACT', compact[:7]))

    # 4. Compound: Name token + Address Number (Strong anchor!)
    if clean_n_toks and addr_nums:
        keys.append(('NAME_NUM', f"{clean_n_toks[0]}_{addr_nums[0]}"))

    # 5. Address Anchor: Street Number + First significant Street Word
    if addr_nums and clean_a_words:
        keys.append(('ADDR_ANCHOR', f"{addr_nums[0]}_{clean_a_words[0]}"))
        if len(clean_a_words) >= 2:
            keys.append(('ADDR_ANCHOR2', f"{addr_nums[0]}_{clean_a_words[1]}"))

    # 6. For single-word names: Name token + Locality/City word
    if len(clean_n_toks) == 1 and clean_a_words:
        keys.append(('NAME_WORD', f"{clean_n_toks[0]}_{clean_a_words[-1]}"))

    return name_clean, clean_n_toks, addr_clean, addr_nums, keys


def score_entity_pair(
    s1_name: str,
    s1_toks: list[str],
    s1_addr: str,
    s1_nums: list[str],
    m_name: str,
    m_toks: list[str],
    m_addr: str,
    m_nums: list[str]
) -> float:
    """
    Computes calibrated composite similarity score (0.0 to 100.0) between S1 and candidate M.
    """
    # 1. Name similarities (RapidFuzz C++ core)
    n_set = fuzz.token_set_ratio(s1_name, m_name)
    n_sort = fuzz.token_sort_ratio(s1_name, m_name)

    # 2. Address similarities
    if s1_addr and m_addr:
        a_set = fuzz.token_set_ratio(s1_addr, m_addr)
        a_sort = fuzz.token_sort_ratio(s1_addr, m_addr)
    else:
        # Neutral baseline if address is absent in one of the records
        a_set = 60.0
        a_sort = 60.0

    # 3. Structural Number Alignment
    num_adj = 0.0
    if s1_nums and m_nums:
        if set(s1_nums) & set(m_nums):
            num_adj = 15.0  # Reward matching building/plot number
        else:
            num_adj = -25.0  # Heavy penalty for conflicting building numbers

    # 4. Brand Token Consistency
    first_token_bonus = 0.0
    if s1_toks and m_toks and s1_toks[0] == m_toks[0]:
        first_token_bonus = 5.0

    # 5. Composite Weighted Score
    score = (
        0.45 * n_set +
        0.15 * n_sort +
        0.25 * a_set +
        0.10 * a_sort +
        first_token_bonus +
        num_adj
    )
    return min(100.0, max(0.0, score))


def run_pipeline(
    test_dir: str = "student_resource/dataset/test",
    output_dir: str = "student_resource/output"
):
    """
    Main pipeline entry point:
    1. Loads test_source1.tsv partitioned by country into memory index.
    2. Sequentially streams test_source2.tsv and test_source3.tsv once.
    3. Writes output/matching_results.tsv and output/candidate_pairs.tsv.
    """
    total_start = time.time()
    os.makedirs(output_dir, exist_ok=True)
    matching_path = os.path.join(output_dir, "matching_results.tsv")
    candidate_path = os.path.join(output_dir, "candidate_pairs.tsv")

    print("================================================================")
    print("      ML CHALLENGE 2026: M-RESOLVER ENTITY RESOLUTION PIPELINE  ")
    print("================================================================")

    # Phase 1: Ingesting Reference Entities (test_source1.tsv)
    print("\n=== Phase 1: Ingesting Reference Entities (test_source1.tsv) ===")
    t_phase1 = time.time()
    s1_order = []
    s1_records = {}
    s1_index_by_country = defaultdict(lambda: defaultdict(list))
    top_candidates = {}

    s1_path = os.path.join(test_dir, "test_source1.tsv")
    with open(s1_path, "r", encoding="utf-8", errors="ignore") as f:
        reader = csv.reader(f, delimiter="\t")
        next(reader, None)  # Skip header

        for row in reader:
            if len(row) < 4:
                continue
            s1_id, name, addr, country = row[0], row[1], row[2], row[3]
            s1_order.append(s1_id)
            top_candidates[s1_id] = []

            name_clean, name_toks, addr_clean, addr_nums, keys = extract_record_keys(name, addr)
            s1_records[s1_id] = (name_clean, name_toks, addr_clean, addr_nums)

            for k in keys:
                s1_index_by_country[country][k].append(s1_id)

    print(f"Total S1 Reference Entities Ingested: {len(s1_order):,} in {time.time()-t_phase1:.1f}s")
    for country, index in sorted(s1_index_by_country.items()):
        print(f"  - {country}: {len(index):,} unique inverted index keys")

    # Phase 2: Streaming S2 and S3 for Candidate Generation and Real-Time Scoring
    print("\n=== Phase 2: Streaming Test Sources (test_source2 & test_source3) ===")
    for src_filename in ("test_source2.tsv", "test_source3.tsv"):
        src_path = os.path.join(test_dir, src_filename)
        t_src = time.time()
        print(f"\n--- Streaming {src_filename} ---")

        row_count = 0
        admissions = 0

        with open(src_path, "r", encoding="utf-8", errors="ignore") as f:
            reader = csv.reader(f, delimiter="\t")
            next(reader, None)  # Skip header

            for row in reader:
                if len(row) < 4:
                    continue
                row_count += 1
                m_id, name, addr, rec_country = row[0], row[1], row[2], row[3]

                country_index = s1_index_by_country.get(rec_country)
                if not country_index:
                    continue

                m_name, m_toks, m_addr, m_nums, keys = extract_record_keys(name, addr)

                # Find candidate S1 references matching any blocking key
                matched_s1 = set()
                for k in keys:
                    bucket = country_index.get(k)
                    if bucket and len(bucket) <= MAX_BUCKET_SIZE:
                        matched_s1.update(bucket)

                # Real-time scoring against matched S1 references
                for s1_id in matched_s1:
                    s1_name, s1_toks, s1_addr, s1_nums = s1_records[s1_id]
                    score = score_entity_pair(
                        s1_name, s1_toks, s1_addr, s1_nums,
                        m_name, m_toks, m_addr, m_nums
                    )

                    if score >= CANDIDATE_ADMISSION_THRESHOLD:
                        admissions += 1
                        heap = top_candidates[s1_id]
                        if len(heap) < TOP_K_CANDIDATES:
                            heapq.heappush(heap, (score, m_id))
                        elif score > heap[0][0]:
                            heapq.heapreplace(heap, (score, m_id))

                if row_count % 1000000 == 0:
                    print(f"  Processed {row_count:,} records ({admissions:,} candidate admissions)...")

        print(f"Finished {src_filename} in {time.time()-t_src:.1f}s ({row_count:,} total records, {admissions:,} candidate admissions)")

    # Phase 3: Exporting Official Submission TSVs
    print("\n=== Phase 3: Exporting Official Submission TSV Files ===")
    t_export = time.time()
    print(f"Writing matching results to: {matching_path}")
    print(f"Writing candidate pairs to:  {candidate_path}")

    total_matches_predicted = 0
    total_singletons_predicted = 0
    total_candidates_emitted = 0

    with open(matching_path, "w", encoding="utf-8", newline="") as f_match, \
         open(candidate_path, "w", encoding="utf-8", newline="") as f_cand:
        
        # Write headers
        f_match.write("source1_entity_id\tmatched_entity_ids\n")
        f_cand.write("source1_entity_id\tcandidate_entity_ids\n")

        for s1_id in s1_order:
            heap = top_candidates.get(s1_id, [])
            # Sort candidates by score descending
            sorted_candidates = sorted(heap, key=lambda x: x[0], reverse=True)

            seen_cands = set()
            candidate_ids = []
            matched_ids = []

            for score, m_id in sorted_candidates:
                if m_id not in seen_cands:
                    seen_cands.add(m_id)
                    candidate_ids.append(m_id)
                    if score >= MATCH_THRESHOLD:
                        matched_ids.append(m_id)

            match_str = ",".join(matched_ids)
            f_match.write(f"{s1_id}\t{match_str}\n")

            cand_str = ",".join(candidate_ids)
            f_cand.write(f"{s1_id}\t{cand_str}\n")

            total_candidates_emitted += len(candidate_ids)
            if matched_ids:
                total_matches_predicted += len(matched_ids)
            else:
                total_singletons_predicted += 1

    print(f"Export completed in {time.time()-t_export:.1f}s")
    print("\n================ PIPELINE EXECUTION SUMMARY ================")
    print(f"Total S1 Entities Processed:      {len(s1_order):,}")
    print(f"Total Predicted Matches:          {total_matches_predicted:,}")
    print(f"Total Predicted Singletons:       {total_singletons_predicted:,} ({total_singletons_predicted/len(s1_order)*100:.2f}%)")
    print(f"Total Candidates Generated:       {total_candidates_emitted:,} (Avg: {total_candidates_emitted/len(s1_order):.2f}/entity)")
    print(f"Total Wall-Clock Time:            {time.time()-total_start:.1f} seconds")
    print("============================================================")


if __name__ == "__main__":
    run_pipeline()
