"""
TF-IDF Character N-Gram Blocking.
Builds a sparse TF-IDF index (char 2-4 gram) over S2/S3 records per country.
Queries each S1 record via batched cosine similarity to retrieve top-K candidates.
Dramatically improves blocking recall for cross-script, abbreviation, and OCR-variant names.
"""

import sys
import time
import numpy as np
import scipy.sparse as sp
from collections import defaultdict
from sklearn.feature_extraction.text import TfidfVectorizer

try:
    from .normalize import normalize_name, normalize_address, LEGAL_SUFFIXES, STOPWORDS
except ImportError:
    from src.normalize import normalize_name, normalize_address, LEGAL_SUFFIXES, STOPWORDS


def build_tfidf_text(name: str, addr: str) -> str:
    """
    Creates a combined search string for TF-IDF indexing.
    Uses normalized name + address numbers and locality tokens.
    """
    name_clean, name_toks = normalize_name(name)
    _, addr_words, addr_nums = normalize_address(addr)
    
    # Include name tokens and address numbers/words
    addr_clean = ' '.join(addr_nums + [w for w in addr_words if w not in STOPWORDS and len(w) >= 3])
    return f"{name_clean} {addr_clean}".strip()


class TFIDFBlocker:
    """
    Country-partitioned TF-IDF character n-gram retrieval index.
    """
    def __init__(self, ngram_range=(2, 4), max_features=200_000, top_k=20, min_score=0.08):
        self.ngram_range = ngram_range
        self.max_features = max_features
        self.top_k = top_k
        self.min_score = min_score
        # Per-country state
        self.vectorizers = {}
        self.matrices = {}     # normalized sparse matrices
        self.id_arrays = {}    # list of entity IDs per country

    def build_index(self, country: str, records: list[tuple[str, str, str]]):
        """
        Builds TF-IDF index for one country.
        records: list of (entity_id, name, addr)
        """
        t0 = time.time()
        ids = [r[0] for r in records]
        texts = [build_tfidf_text(r[1], r[2]) for r in records]
        
        vec = TfidfVectorizer(
            analyzer='char_wb',
            ngram_range=self.ngram_range,
            max_features=self.max_features,
            sublinear_tf=True,
            dtype=np.float32
        )
        M = vec.fit_transform(texts)
        
        # L2-normalize rows for cosine similarity via dot product
        row_norms = np.asarray(M.multiply(M).sum(axis=1)).flatten() ** 0.5
        row_norms[row_norms == 0] = 1.0
        M_norm = M.multiply(1.0 / row_norms.reshape(-1, 1))
        
        self.vectorizers[country] = vec
        self.matrices[country] = M_norm.tocsr()
        self.id_arrays[country] = ids
        
        print(f"  [TF-IDF] Built {country} index: {M.shape[0]:,} docs, {M.shape[1]:,} features in {time.time()-t0:.1f}s")

    def query(self, country: str, query_records: list[tuple[str, str, str]]) -> dict[str, set[str]]:
        """
        Queries the TF-IDF index for a batch of S1 entities.
        query_records: list of (s1_id, name, addr)
        Returns: dict mapping s1_id -> set of candidate entity_ids
        """
        if country not in self.vectorizers:
            return {r[0]: set() for r in query_records}
        
        vec = self.vectorizers[country]
        M_norm = self.matrices[country]
        ids = self.id_arrays[country]
        
        results = {}
        
        # Process in batches of 1000 for memory efficiency
        batch_size = 1000
        for batch_start in range(0, len(query_records), batch_size):
            batch = query_records[batch_start:batch_start + batch_size]
            s1_ids = [r[0] for r in batch]
            texts = [build_tfidf_text(r[1], r[2]) for r in batch]
            
            Q = vec.transform(texts)
            q_norms = np.asarray(Q.multiply(Q).sum(axis=1)).flatten() ** 0.5
            q_norms[q_norms == 0] = 1.0
            Q_norm = Q.multiply(1.0 / q_norms.reshape(-1, 1))
            
            # Batched cosine similarity
            sim_matrix = (Q_norm @ M_norm.T).toarray()
            
            for i, s1_id in enumerate(s1_ids):
                scores = sim_matrix[i]
                top_indices = np.argpartition(scores, -min(self.top_k, len(scores)))[-self.top_k:]
                top_indices = top_indices[scores[top_indices] >= self.min_score]
                top_indices = top_indices[np.argsort(-scores[top_indices])]
                results[s1_id] = set(ids[j] for j in top_indices)
        
        return results
