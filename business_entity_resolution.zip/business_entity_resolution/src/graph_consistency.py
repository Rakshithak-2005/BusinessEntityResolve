"""
Graph Consistency Post-Processing.

After the matching model produces predictions, applies connected-component clustering:
- If S1-A matches S2-X, and S2-X also matches S1-B via the same cluster, we can
  propagate evidence to improve recall.
- If two S1 entities are predicted to share the same S2/S3 match but have conflicting
  attributes, we can prune lower-confidence predictions.

Uses Union-Find (Disjoint Set Union) for O(alpha(N)) operations.
"""

from collections import defaultdict


class UnionFind:
    """Efficient Union-Find with path compression and union by rank."""
    def __init__(self):
        self.parent = {}
        self.rank = {}

    def find(self, x):
        if x not in self.parent:
            self.parent[x] = x
            self.rank[x] = 0
        if self.parent[x] != x:
            self.parent[x] = self.find(self.parent[x])  # path compression
        return self.parent[x]

    def union(self, x, y):
        rx, ry = self.find(x), self.find(y)
        if rx == ry:
            return
        # Union by rank
        if self.rank[rx] < self.rank[ry]:
            rx, ry = ry, rx
        self.parent[ry] = rx
        if self.rank[rx] == self.rank[ry]:
            self.rank[rx] += 1

    def get_components(self) -> dict[str, set[str]]:
        """Returns {root: set of members} for all components."""
        components = defaultdict(set)
        for node in self.parent:
            root = self.find(node)
            components[root].add(node)
        return dict(components)


def apply_graph_consistency(
    predictions: dict[str, set[str]],
    probabilities: dict[tuple[str, str], float],
    min_cluster_prob: float = 0.55
) -> dict[str, set[str]]:
    """
    Applies connected-component transitivity to predictions.
    
    Logic:
    1. If S2-X or S3-X is matched to multiple S1 entities, group them into a cluster.
    2. Within a cluster, propagate the high-confidence matches: if one S1 entity in the
       cluster has a strong match to S2-X, other S1 entities in the cluster also get it.
    3. Prune spurious singletons in the cluster using probability thresholds.
    
    Returns cleaned predictions dict.
    """
    # Build inverted index: S2/S3 match -> set of S1 entities predicting it
    s23_to_s1 = defaultdict(set)
    for s1_id, match_set in predictions.items():
        for m_id in match_set:
            s23_to_s1[m_id].add(s1_id)

    # Find clusters: S1 entities sharing any S2/S3 match form a cluster
    uf = UnionFind()
    for m_id, s1_set in s23_to_s1.items():
        s1_list = list(s1_set)
        for i in range(1, len(s1_list)):
            uf.union(s1_list[0], s1_list[i])

    # Get components
    components = uf.get_components()

    # For each cluster: collect all predicted matches and confidences
    # Only propagate if the cluster is coherent (not too large and high avg confidence)
    cleaned = {}
    clustered_s1 = set()

    for root, cluster_s1 in components.items():
        if len(cluster_s1) == 1:
            # Singleton S1 cluster — no propagation needed
            s1_id = next(iter(cluster_s1))
            cleaned[s1_id] = predictions.get(s1_id, set())
            clustered_s1.add(s1_id)
            continue

        # Multi-S1 cluster — only propagate if all S1 members are of same country
        # and cluster is reasonably small (prevents mass propagation errors)
        if len(cluster_s1) > 5:
            # Too large — keep individual predictions without propagation
            for s1_id in cluster_s1:
                cleaned[s1_id] = predictions.get(s1_id, set())
                clustered_s1.add(s1_id)
            continue

        # Collect all matches in this cluster and their max confidence
        cluster_matches = defaultdict(float)
        for s1_id in cluster_s1:
            for m_id in predictions.get(s1_id, set()):
                prob = probabilities.get((s1_id, m_id), min_cluster_prob)
                cluster_matches[m_id] = max(cluster_matches[m_id], prob)

        # Propagate high-confidence matches to all S1 entities in the cluster
        shared_matches = {m_id for m_id, prob in cluster_matches.items() if prob >= min_cluster_prob}
        for s1_id in cluster_s1:
            # Union of their original predictions + shared high-confidence matches
            orig = predictions.get(s1_id, set())
            cleaned[s1_id] = orig | shared_matches
            clustered_s1.add(s1_id)

    # Add any S1 entities not in any cluster (had no predictions)
    for s1_id, match_set in predictions.items():
        if s1_id not in clustered_s1:
            cleaned[s1_id] = match_set

    return cleaned


def apply_singleton_protection(
    predictions: dict[str, set[str]],
    probabilities: dict[tuple[str, str], float],
    high_precision_threshold: float = 0.80
) -> dict[str, set[str]]:
    """
    For entities with many predicted matches, only keep very high confidence ones.
    Protects against false merges on ambiguous entities (common business names).
    """
    cleaned = {}
    for s1_id, match_set in predictions.items():
        if len(match_set) <= 3:
            cleaned[s1_id] = match_set
            continue

        # Too many matches — filter to only high-confidence ones
        high_conf = {
            m_id for m_id in match_set
            if probabilities.get((s1_id, m_id), 0.5) >= high_precision_threshold
        }
        cleaned[s1_id] = high_conf if high_conf else match_set

    return cleaned
