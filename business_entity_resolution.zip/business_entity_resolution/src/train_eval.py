"""
Train LightGBM matcher on training dataset slice and evaluate on validation set.
"""

import csv
import sys
import time
import random
import numpy as np
from collections import defaultdict

try:
    from .normalize import normalize_name, normalize_address
    from .blocking import extract_blocking_keys, BlockingIndex
    from .features import compute_pair_features
    from .models import EntityMatchingModel
    from .metrics import evaluate_predictions
except ImportError:
    from src.normalize import normalize_name, normalize_address
    from src.blocking import extract_blocking_keys, BlockingIndex
    from src.features import compute_pair_features
    from src.models import EntityMatchingModel
    from src.metrics import evaluate_predictions

sys.stdout.reconfigure(encoding='utf-8')

def run_train_val(train_size=30000, val_size=10000):
    t0 = time.time()
    random.seed(42)
    np.random.seed(42)

    print("=== Step 1: Loading Training and Validation Reference Entities (S1) ===")
    s1_train = {}
    s1_val = {}
    total_needed = train_size + val_size

    with open('student_resource/dataset/train/train_source1.tsv', 'r', encoding='utf-8', errors='ignore') as f:
        r = csv.reader(f, delimiter='\t')
        next(r)
        for i, row in enumerate(r):
            eid, name, addr, country = row[0], row[1], row[2], row[3]
            name_clean, name_toks = normalize_name(name)
            addr_clean, addr_words, addr_nums = normalize_address(addr)
            keys = extract_blocking_keys(name, addr)
            
            record = {
                'id': eid, 'name_clean': name_clean, 'name_toks': name_toks,
                'addr_clean': addr_clean, 'addr_nums': addr_nums, 'country': country,
                'keys': keys
            }
            if len(s1_train) < train_size:
                s1_train[eid] = record
            elif len(s1_val) < val_size:
                s1_val[eid] = record
            else:
                break

    print(f"Loaded {len(s1_train)} train S1 and {len(s1_val)} val S1 in {time.time()-t0:.1f}s")

    print("=== Step 2: Loading Ground Truth ===")
    train_gt = {}
    val_gt = {}
    train_target_ids = set()
    val_target_ids = set()

    with open('student_resource/dataset/train/train_ground_truth.tsv', 'r', encoding='utf-8', errors='ignore') as f:
        r = csv.reader(f, delimiter='\t')
        next(r)
        for row in r:
            s1_id = row[0]
            matches = [m.strip() for m in row[1].split(',') if m.strip()] if len(row) > 1 and row[1] else []
            if s1_id in s1_train:
                train_gt[s1_id] = set(matches)
                train_target_ids.update(matches)
            elif s1_id in s1_val:
                val_gt[s1_id] = set(matches)
                val_target_ids.update(matches)

    all_targets = train_target_ids | val_target_ids
    print(f"Ground truth loaded: {len(train_gt)} train, {len(val_gt)} val ({len(all_targets):,} target S2/S3 IDs)")

    # Build S1 blocking indexes per country
    print("=== Step 3: Indexing S1 entities for Candidate Retrieval ===")
    train_index_by_country = defaultdict(BlockingIndex)
    val_index_by_country = defaultdict(BlockingIndex)

    for eid, rec in s1_train.items():
        train_index_by_country[rec['country']].add(eid, rec['keys'])

    for eid, rec in s1_val.items():
        val_index_by_country[rec['country']].add(eid, rec['keys'])

    # Stream S2 and S3 to gather candidate pairs and true target records
    print("=== Step 4: Streaming S2 and S3 for Candidate Generation ===")
    train_candidates = defaultdict(set)
    val_candidates = defaultdict(set)
    target_records = {} # store attributes of true matches and candidate matches

    sources = [
        'student_resource/dataset/train/train_source2.tsv',
        'student_resource/dataset/train/train_source3.tsv'
    ]

    for src_path in sources:
        t_src = time.time()
        with open(src_path, 'r', encoding='utf-8', errors='ignore') as f:
            r = csv.reader(f, delimiter='\t')
            next(r)
            for i, row in enumerate(r):
                eid, name, addr, country = row[0], row[1], row[2], row[3]
                
                # Check if this record is a target or matches any S1
                keys = extract_blocking_keys(name, addr)
                
                # Check train S1 index
                train_matched_s1 = set()
                if country in train_index_by_country:
                    train_matched_s1 = train_index_by_country[country].get_candidates(keys, max_cands=30)
                    for s1 in train_matched_s1:
                        if len(train_candidates[s1]) < 30:
                            train_candidates[s1].add(eid)

                # Check val S1 index
                val_matched_s1 = set()
                if country in val_index_by_country:
                    val_matched_s1 = val_index_by_country[country].get_candidates(keys, max_cands=30)
                    for s1 in val_matched_s1:
                        if len(val_candidates[s1]) < 30:
                            val_candidates[s1].add(eid)

                # Save record if it is a candidate or a true target
                if eid in all_targets or train_matched_s1 or val_matched_s1:
                    name_clean, name_toks = normalize_name(name)
                    addr_clean, addr_words, addr_nums = normalize_address(addr)
                    target_records[eid] = {
                        'name_clean': name_clean, 'name_toks': name_toks,
                        'addr_clean': addr_clean, 'addr_nums': addr_nums
                    }

                if (i + 1) % 1500000 == 0:
                    print(f"Processed {i+1:,} rows of {src_path}...")
        print(f"Completed {src_path} in {time.time()-t_src:.1f}s")

    # Evaluate Candidate Recall on Validation Split
    val_total_gt = sum(len(ms) for ms in val_gt.values())
    val_cand_gt = sum(len(val_gt[s1] & val_candidates[s1]) for s1 in val_gt)
    print(f"\n[Validation Blocking Recall] {val_cand_gt:,} / {val_total_gt:,} ({val_cand_gt/val_total_gt*100:.2f}%)")
    val_cand_counts = [len(val_candidates[s1]) for s1 in s1_val]
    print(f"Avg candidates per Val S1: {sum(val_cand_counts)/len(val_cand_counts):.1f}")

    # Build Training Dataset (Positives + Hard Negatives)
    print("\n=== Step 5: Extracting Features for Training ===")
    X_train = []
    y_train = []

    for s1_id, rec in s1_train.items():
        true_ms = train_gt.get(s1_id, set())
        
        # 1. Positive examples
        for m_id in true_ms:
            if m_id in target_records:
                m_rec = target_records[m_id]
                feats = compute_pair_features(
                    rec['name_clean'], rec['name_toks'], rec['addr_clean'], rec['addr_nums'],
                    m_rec['name_clean'], m_rec['name_toks'], m_rec['addr_clean'], m_rec['addr_nums']
                )
                X_train.append(feats)
                y_train.append(1)

        # 2. Hard Negative examples (candidates that are not in true_ms)
        cands = train_candidates.get(s1_id, set())
        neg_cands = [c for c in cands if c not in true_ms]
        sampled_negs = random.sample(neg_cands, min(len(neg_cands), 3))
        for m_id in sampled_negs:
            if m_id in target_records:
                m_rec = target_records[m_id]
                feats = compute_pair_features(
                    rec['name_clean'], rec['name_toks'], rec['addr_clean'], rec['addr_nums'],
                    m_rec['name_clean'], m_rec['name_toks'], m_rec['addr_clean'], m_rec['addr_nums']
                )
                X_train.append(feats)
                y_train.append(0)

    X_train = np.array(X_train, dtype=np.float32)
    y_train = np.array(y_train, dtype=np.int32)
    print(f"Training dataset: {len(X_train):,} samples (Positives: {sum(y_train):,}, Negatives: {len(y_train)-sum(y_train):,})")

    print("\n=== Step 6: Fitting LightGBM Matcher ===")
    matcher = EntityMatchingModel()
    matcher.fit(X_train, y_train)

    print("\n=== Step 7: Scoring Validation Candidates & Optimizing Threshold ===")
    val_pairs = [] # (s1, m, prob)
    for s1_id, rec in s1_val.items():
        cands = val_candidates.get(s1_id, set())
        if not cands: continue
        
        cand_list = [c for c in cands if c in target_records]
        if not cand_list: continue

        X_cand = []
        for m_id in cand_list:
            m_rec = target_records[m_id]
            feats = compute_pair_features(
                rec['name_clean'], rec['name_toks'], rec['addr_clean'], rec['addr_nums'],
                m_rec['name_clean'], m_rec['name_toks'], m_rec['addr_clean'], m_rec['addr_nums']
            )
            X_cand.append(feats)

        probs = matcher.predict_proba(np.array(X_cand, dtype=np.float32))
        for m_id, prob in zip(cand_list, probs):
            val_pairs.append((s1_id, m_id, float(prob)))

    # Find optimal threshold
    best_thresh = matcher.optimize_threshold(val_pairs, val_gt)

    # Compute final metrics on validation set
    final_preds = defaultdict(set)
    for s1, m, p in val_pairs:
        if p >= best_thresh:
            final_preds[s1].add(m)

    eval_results = evaluate_predictions(final_preds, val_gt)
    print("\n=== FINAL VALIDATION RESULTS ===")
    print(f"Macro F_0.5 Score:     {eval_results['macro_f05']:.4f}")
    print(f"Macro Precision:       {eval_results['macro_precision']:.4f}")
    print(f"Macro Recall:          {eval_results['macro_recall']:.4f}")
    print(f"Singleton Accuracy:    {eval_results['singleton_accuracy']*100:.2f}%")
    print(f"Total Val Entities:    {eval_results['total_evaluated']}")
    print(f"Total Elapsed Time:    {time.time()-t0:.1f}s")

    return matcher, eval_results


if __name__ == '__main__':
    run_train_val()
