import re
import unicodedata

# Legal entity suffixes across US, India, and France
LEGAL_SUFFIXES = {
    'inc', 'incorporated', 'corp', 'corporation', 'llc', 'ltd', 'limited',
    'pvt', 'private', 'llp', 'co', 'company', 'enterprises', 'enterprise',
    'holdings', 'group', 'services', 'solutions', 'technologies',
    'center', 'centre', 'associates',
    # French legal suffixes & company forms
    'sa', 'sarl', 'sas', 'sasu', 'eurl', 'snc', 'sca', 'sci', 'selarl',
    'cie', 'fils'
}

STOPWORDS = {
    'and', 'the', 'of', 'in', 'for', 'to', 'a', 'an', 'at', 'by',
    'near', 'opp', 'opposite', 'beside', 'behind',
    'floor', 'block', 'sector', 'plot', 'shop', 'door',
    # French stopwords
    'de', 'du', 'des', 'le', 'la', 'les', 'et', 'en', 'sur', 'dans'
}

US_STATES = {
    'alabama': 'al', 'alaska': 'ak', 'arizona': 'az', 'arkansas': 'ar', 'california': 'ca',
    'colorado': 'co', 'connecticut': 'ct', 'delaware': 'de', 'florida': 'fl', 'georgia': 'ga',
    'hawaii': 'hi', 'idaho': 'id', 'illinois': 'il', 'indiana': 'in', 'iowa': 'ia',
    'kansas': 'ks', 'kentucky': 'ky', 'louisiana': 'la', 'maine': 'me', 'maryland': 'md',
    'massachusetts': 'ma', 'michigan': 'mi', 'minnesota': 'mn', 'mississippi': 'ms', 'missouri': 'mo',
    'montana': 'mt', 'nebraska': 'ne', 'nevada': 'nv', 'new hampshire': 'nh', 'new jersey': 'nj',
    'new mexico': 'nm', 'new york': 'ny', 'north carolina': 'nc', 'north dakota': 'nd', 'ohio': 'oh',
    'oklahoma': 'ok', 'oregon': 'or', 'pennsylvania': 'pa', 'rhode island': 'ri', 'south carolina': 'sc',
    'south dakota': 'sd', 'tennessee': 'tn', 'texas': 'tx', 'utah': 'ut', 'vermont': 'vt',
    'virginia': 'va', 'washington': 'wa', 'west virginia': 'wv', 'wisconsin': 'wi', 'wyoming': 'wy'
}

INDIA_STATES = {
    'tamil nadu': 'tn', 'uttar pradesh': 'up', 'rajasthan': 'rj', 'maharashtra': 'mh',
    'karnataka': 'ka', 'delhi': 'dl', 'west bengal': 'wb', 'gujarat': 'gj',
    'andhra pradesh': 'ap', 'telangana': 'ts', 'madhya pradesh': 'mp', 'bihar': 'br',
    'punjab': 'pb', 'haryana': 'hr', 'kerala': 'kl', 'odisha': 'or', 'jharkhand': 'jh',
    'assam': 'as', 'uttarakhand': 'uk', 'chhattisgarh': 'cg', 'himachal pradesh': 'hp'
}

STREET_NORMALIZATION = {
    # English street types
    'saint': 'st', 'street': 'st', 'road': 'rd', 'avenue': 'ave', 'drive': 'dr',
    'boulevard': 'blvd', 'lane': 'ln', 'court': 'ct', 'place': 'pl',
    'terrace': 'terr', 'highway': 'hwy', 'parkway': 'pkwy', 'circle': 'cir',
    'expressway': 'expwy',
    # French street abbreviations & types
    'r': 'rue', 'rue': 'rue', 'av': 'ave', 'avenue': 'ave',
    'bd': 'blvd', 'boulevard': 'blvd', 'che': 'chemin', 'chemin': 'chemin',
    'rte': 'route', 'route': 'route', 'imp': 'impasse', 'impasse': 'impasse',
    'all': 'allee', 'allee': 'allee', 'pl': 'place'
}


def strip_accents(text: str) -> str:
    if not text:
        return ""
    text = unicodedata.normalize('NFKD', text)
    return ''.join(c for c in text if not unicodedata.combining(c))


def is_indic_non_ascii(text: str) -> bool:
    """Checks if text contains non-ASCII characters (e.g. Devanagari, Tamil)."""
    return any(ord(c) > 127 for c in text) if text else False


def soundex(token: str) -> str:
    """Phonetic Soundex encoding for typo and spelling invariant blocking."""
    if not token or not token[0].isalpha():
        return ""
    token = token.upper()
    mapping = {'BFPV': '1', 'CGJKQSXZ': '2', 'DT': '3', 'L': '4', 'MN': '5', 'R': '6'}
    code = [token[0]]
    for c in token[1:]:
        digit = ''
        for keys, val in mapping.items():
            if c in keys:
                digit = val
                break
        if digit and digit != code[-1]:
            code.append(digit)
    code = ''.join(code) + '0000'
    return code[:4]


def extract_char_3grams(text: str, max_grams: int = 4) -> list[str]:
    """Extract character 3-grams for fuzzy blocking."""
    clean = re.sub(r'[^a-z0-9]', '', text.lower())
    if len(clean) < 3:
        return [clean] if clean else []
    return [clean[i:i+3] for i in range(min(max_grams, len(clean) - 2))]


def clean_text(text: str) -> list[str]:
    """Tokenize, normalize unicode, strip urls/domains, fix leet characters, and normalize numbers."""
    if not text:
        return []
    text = strip_accents(text).lower()
    text = re.sub(r'https?://\S+|www\.\S+|\.com|\.org|\.net|\.in|\.co|\.fr', ' ', text)
    # Remove bracket artifacts common in French records (e.g. [EURL], << >>)
    text = re.sub(r'[\[\]<>]', ' ', text)
    text = re.sub(r'[^a-z0-9\s]', ' ', text)
    tokens = text.split()
    
    norm_tokens = []
    for t in tokens:
        # OCR / Leet-speak substitution: 0 -> o inside mixed alpha tokens
        if '0' in t and any(c.isalpha() for c in t):
            t = t.replace('0', 'o')
        # Normalize digits by stripping leading zeros
        if t.isdigit():
            t = str(int(t))
        norm_tokens.append(t)
    return norm_tokens


def normalize_name(name: str) -> tuple[str, list[str]]:
    """Returns normalized name string and list of non-suffix tokens."""
    tokens = clean_text(name)
    content_tokens = [w for w in tokens if w not in LEGAL_SUFFIXES]
    if not content_tokens:
        content_tokens = tokens
    return ' '.join(content_tokens), content_tokens


def normalize_address(address: str) -> tuple[str, list[str], list[str]]:
    """
    Returns normalized address string, list of words, and list of numbers.
    """
    raw_tokens = clean_text(address)
    words = []
    numbers = []
    
    for t in raw_tokens:
        if t.isdigit():
            numbers.append(t)
        else:
            norm_w = STREET_NORMALIZATION.get(t, t)
            words.append(norm_w)
            
    norm_address_str = ' '.join(numbers + words)
    return norm_address_str, words, numbers
