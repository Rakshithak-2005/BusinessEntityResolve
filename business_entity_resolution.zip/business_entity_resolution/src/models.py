"""
Matching Model and Threshold Optimizer.
Trains a LightGBM Classifier on similarity feature vectors.
Optimizes decision threshold directly for Macro F_0.5 score.
"""

import numpy as np
import lightgbm as lgb
try:
    from .metrics import compute_entity_f05
except ImportError:
    from src.metrics import compute_entity_f05


class EntityMatchingModel:
    def __init__(self):
        self.model = lgb.LGBMClassifier(
            n_estimators=150,
            learning_rate=0.08,
            max_depth=6,
            num_leaves=31,
            subsample=0.8,
            colsample_bytree=0.8,
            random_state=42,
            n_jobs=4,
            verbose=-1
        )
        self.best_threshold = 0.65

    def fit(self, X: np.ndarray, y: np.ndarray):
        """Fit LightGBM on pair features."""
        self.model.fit(X, y)

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """Returns match probabilities."""
        return self.model.predict_proba(X)[:, 1]

    def optimize_threshold(
        self,
        val_pairs: list[tuple[str, str, float]],
        val_ground_truth: dict[str, set[str]],
        thresholds: list[float] | None = None
    ) -> float:
        """
        Finds the decision threshold that maximizes Macro F_0.5 on the validation set.
        val_pairs: list of (s1_id, m_id, prob)
        """
        if thresholds is None:
            thresholds = [0.45, 0.50, 0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85]

        # Group probabilities by s1_id
        from collections import defaultdict
        s1_to_preds = defaultdict(list)
        for s1, m, prob in val_pairs:
            s1_to_preds[s1].append((m, prob))

        best_score = -1.0
        best_t = 0.65

        for t in thresholds:
            f05_list = []
            for s1, true_set in val_ground_truth.items():
                pred_candidates = s1_to_preds.get(s1, [])
                pred_matches = {m for m, p in pred_candidates if p >= t}
                f05, _, _ = compute_entity_f05(pred_matches, true_set)
                f05_list.append(f05)

            macro_score = sum(f05_list) / len(f05_list) if f05_list else 0.0
            print(f"Threshold {t:.2f} -> Macro F_0.5: {macro_score:.4f}")

            if macro_score > best_score:
                best_score = macro_score
                best_t = t

        print(f"Optimal Threshold: {best_t:.2f} (Macro F_0.5: {best_score:.4f})")
        self.best_threshold = best_t
        return best_t
