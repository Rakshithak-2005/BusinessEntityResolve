"""
Feature extraction for Candidate Pairs using RapidFuzz.
Extracts string distances, token set/sort ratios, and structural address number overlap.
"""

from rapidfuzz import fuzz
try:
    from .normalize import normalize_name, normalize_address
except ImportError:
    from src.normalize import normalize_name, normalize_address


def compute_pair_features(
    s1_name_clean: str,
    s1_name_tokens: list[str],
    s1_addr_clean: str,
    s1_addr_nums: list[str],
    m_name_clean: str,
    m_name_tokens: list[str],
    m_addr_clean: str,
    m_addr_nums: list[str]
) -> list[float]:
    """
    Computes a vector of 9 similarity features for a candidate pair.
    """
    # 1. Name string similarities
    n_ratio = fuzz.ratio(s1_name_clean, m_name_clean)
    n_sort = fuzz.token_sort_ratio(s1_name_clean, m_name_clean)
    n_set = fuzz.token_set_ratio(s1_name_clean, m_name_clean)
    
    # 2. Address string similarities
    if s1_addr_clean and m_addr_clean:
        a_sort = fuzz.token_sort_ratio(s1_addr_clean, m_addr_clean)
        a_set = fuzz.token_set_ratio(s1_addr_clean, m_addr_clean)
    else:
        a_sort = 0.0
        a_set = 0.0

    # 3. Structural address number matching
    s1_num_set = set(s1_addr_nums)
    m_num_set = set(m_addr_nums)
    if s1_num_set and m_num_set:
        num_match = 1.0 if (s1_num_set & m_num_set) else 0.0
    else:
        num_match = 0.5  # Neutral if one address has no numbers

    # 4. Combined full text similarity
    s1_comb = f"{s1_name_clean} {s1_addr_clean}"
    m_comb = f"{m_name_clean} {m_addr_clean}"
    comb_set = fuzz.token_set_ratio(s1_comb, m_comb)

    # 5. First word match
    first_word_match = 1.0 if (s1_name_tokens and m_name_tokens and s1_name_tokens[0] == m_name_tokens[0]) else 0.0

    # 6. Length ratio
    l1, l2 = len(s1_name_clean), len(m_name_clean)
    len_sim = min(l1, l2) / max(l1, l2) if max(l1, l2) > 0 else 1.0

    return [
        n_ratio / 100.0,
        n_sort / 100.0,
        n_set / 100.0,
        a_sort / 100.0,
        a_set / 100.0,
        num_match,
        comb_set / 100.0,
        first_word_match,
        len_sim
    ]
