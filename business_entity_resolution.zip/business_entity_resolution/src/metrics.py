"""
Evaluation metrics for Entity Resolution under macro F_0.5.
Precision is weighted twice as heavily as recall: beta = 0.5.
Singletons (entities with 0 matches) score 1.0 on empty predictions and 0.0 otherwise.
"""

def compute_entity_f05(pred_set: set, true_set: set) -> tuple[float, float, float]:
    """
    Computes (f05, precision, recall) for a single Source 1 entity.
    """
    if not pred_set and not true_set:
        return 1.0, 1.0, 1.0  # Correctly predicted singleton
    if not pred_set and true_set:
        return 0.0, 0.0, 0.0  # Missed all matches
    if pred_set and not true_set:
        return 0.0, 0.0, 0.0  # False merge on singleton

    true_positives = len(pred_set & true_set)
    if true_positives == 0:
        return 0.0, 0.0, 0.0

    precision = true_positives / len(pred_set)
    recall = true_positives / len(true_set)

    # F_0.5 formula: (1.25 * P * R) / (0.25 * P + R)
    f05 = (1.25 * precision * recall) / (0.25 * precision + recall)
    return f05, precision, recall


def evaluate_predictions(predictions: dict[str, set], ground_truth: dict[str, set]) -> dict:
    """
    Evaluates predictions across all Source 1 entities in ground_truth.
    Returns summary dictionary with macro F_0.5, macro precision, macro recall, and singleton metrics.
    """
    f05_scores = []
    precision_scores = []
    recall_scores = []
    
    total_singletons = 0
    correct_singletons = 0
    total_entities_with_matches = 0

    for s1_id, true_set in ground_truth.items():
        pred_set = predictions.get(s1_id, set())
        f05, prec, rec = compute_entity_f05(pred_set, true_set)
        
        f05_scores.append(f05)
        precision_scores.append(prec)
        recall_scores.append(rec)

        if not true_set:
            total_singletons += 1
            if not pred_set:
                correct_singletons += 1
        else:
            total_entities_with_matches += 1

    macro_f05 = sum(f05_scores) / len(f05_scores) if f05_scores else 0.0
    macro_prec = sum(precision_scores) / len(precision_scores) if precision_scores else 0.0
    macro_rec = sum(recall_scores) / len(recall_scores) if recall_scores else 0.0

    return {
        "macro_f05": macro_f05,
        "macro_precision": macro_prec,
        "macro_recall": macro_rec,
        "total_evaluated": len(f05_scores),
        "total_singletons": total_singletons,
        "singleton_accuracy": correct_singletons / total_singletons if total_singletons else 0.0,
        "total_non_singletons": total_entities_with_matches
    }
