#!/usr/bin/env python3
"""
ML Challenge 2026: Master End-to-End Pipeline Runner
Team: M-RESOLVER AI

Executes the complete Entity Resolution pipeline from raw test data to validated submission files:
1. Multilingual & multi-jurisdiction normalization (US, India, France)
2. Multi-facet inverted index blocking with dynamic selectivity pruning
3. Real-time C++ RapidFuzz 11D similarity scoring and top-K candidate budgeting
4. F_0.5 precision calibration (cardinality alignment to empirical ground truth)
5. Exporting matching_results.tsv and candidate_pairs.tsv

Usage:
    python run.py [--test-dir PATH] [--output-dir PATH]
"""

import os
import sys
import argparse
import time

# Ensure package root is in sys.path
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if SCRIPT_DIR not in sys.path:
    sys.path.insert(0, SCRIPT_DIR)

from src.pipeline import run_pipeline
from src.optimize_predictions import optimize_submission


def main():
    parser = argparse.ArgumentParser(
        description="M-RESOLVER: End-to-End Entity Resolution for ML Challenge 2026"
    )
    parser.add_argument(
        "--test-dir",
        type=str,
        default=os.path.join(SCRIPT_DIR, "..", "..", "student_resource", "dataset", "test"),
        help="Path to directory containing test_source1.tsv, test_source2.tsv, test_source3.tsv"
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default=os.path.join(SCRIPT_DIR, "..", "..", "student_resource", "output"),
        help="Path to directory where matching_results.tsv and candidate_pairs.tsv will be written"
    )
    args = parser.parse_args()

    # Normalize paths
    test_dir = os.path.abspath(args.test_dir)
    output_dir = os.path.abspath(args.output_dir)

    print("==================================================================")
    print("      ML CHALLENGE 2026: M-RESOLVER MASTER PIPELINE RUNNER       ")
    print("==================================================================")
    print(f"Test Directory:   {test_dir}")
    print(f"Output Directory: {output_dir}")

    if not os.path.isdir(test_dir):
        # Check alternative common paths
        alt_paths = [
            "student_resource/dataset/test",
            "dataset/test",
            "../dataset/test"
        ]
        found = False
        for alt in alt_paths:
            if os.path.isdir(alt):
                test_dir = os.path.abspath(alt)
                found = True
                break
        if not found:
            print(f"ERROR: Test directory not found: {test_dir}")
            sys.exit(1)

    t_start = time.time()

    # Step 1: Run core streaming pipeline
    print("\n[Step 1/2] Running Multi-Facet Blocking & RapidFuzz Scoring Engine...")
    run_pipeline(test_dir=test_dir, output_dir=output_dir)

    # Step 2: Run F_0.5 Cardinality & Precision Optimization
    print("\n[Step 2/2] Applying F_0.5 Precision Calibration & Singleton Protection...")
    raw_matching = os.path.join(output_dir, "matching_results.tsv")
    opt_matching = os.path.join(output_dir, "matching_results_opt.tsv")
    optimize_submission(
        matching_in=raw_matching,
        matching_out=opt_matching,
        max_matches_per_entity=4
    )
    # Replace with optimized version
    os.replace(opt_matching, raw_matching)

    print("\n==================================================================")
    print("PIPELINE COMPLETED SUCCESSFULLY!")
    print(f"Final Outputs written to: {output_dir}")
    print(f"  1. matching_results.tsv (Leaderboard Submission)")
    print(f"  2. candidate_pairs.tsv  (Blocking Candidates)")
    print(f"Total Execution Time: {time.time()-t_start:.1f} seconds")
    print("==================================================================")


if __name__ == "__main__":
    main()
