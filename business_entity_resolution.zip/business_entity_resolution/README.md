# M-RESOLVER: Multi-Evidence Adaptive Entity Resolution
### ML Challenge 2026 — Business Entity Resolution Challenge
**Team:** M-RESOLVER AI  
**License:** MIT  

---

## 1. Executive Summary

**M-RESOLVER** is a production-grade, high-throughput Entity Resolution system engineered to resolve heterogeneous corporate records across multiple noisy data sources at massive scale (**over 11.7 million test records**). 

The system is specifically tailored to the nuances of commercial entity data:
- **Multilingual Indic Script Transliterations** (English $\leftrightarrow$ Devanagari/Hindi and Tamil).
- **Open-World Generalization** to unseen geographical domains (**France** in test set vs. US/India in train set).
- **Severe Injected Noise** (OCR leet-speak substitutions, domain injections, missing address attributes).
- **Macro $F_{0.5}$ Precision Weighting** ($\beta = 0.5$) with singleton penalty protection.
- **Strict Compute & Memory Bounds** (runs within 16 GB RAM without GPU acceleration).

---

## 2. System Architecture

```
+-------------------------------------------------------------------------------------------------+
|                                     M-RESOLVER ARCHITECTURE                                     |
+-------------------------------------------------------------------------------------------------+
|                                                                                                 |
|   [Reference Source 1] ---> Multilingual Normalization & Multi-Facet Compound Key Extraction    |
|                                       |                                                         |
|                                       v                                                         |
|                      [Country-Stratified Inverted Index Buckets]                                |
|                      (NFULL, N2, NSORT, NCOMPACT, PHON_ADDR, NAME_NUM, ADDR_ANCHOR)             |
|                                       ^                                                         |
|   [Stream Sources 2 & 3] ---> Dynamic Selectivity Pruning (Bucket Size <= 40)                   |
|                                       |                                                         |
|                                       v                                                         |
|                    [Real-Time RapidFuzz C++ 11D Similarity Engine]                              |
|       (Token Sort/Set, Levenshtein, Structural Number Match/Conflict, Brand Consistency)        |
|                                       |                                                         |
|                                       v                                                         |
|                     [Streaming Top-K Min-Heap Candidate Budgeting]                              |
|                     (Bounded memory: <= 15 candidates per S1 reference entity)                  |
|                                       |                                                         |
|                     +-----------------+-----------------+                                       |
|                     |                                   |                                       |
|                     v                                   v                                       |
|          [F_0.5 Cardinality &                    [Blocking Candidate Set]                       |
|           Precision Calibration]                 (All Top-15 Candidates)                        |
|           (Threshold Gating >= 78.0                     |                                       |
|            + Top-4 Match Capping)                       v                                       |
|                     |                          candidate_pairs.tsv                              |
|                     v                                                                           |
|          matching_results.tsv                                                                   |
|                                                                                                 |
+-------------------------------------------------------------------------------------------------+
```

---

## 3. Key Technical Innovations

### A. Multi-Facet Compound Inverted Index Blocking
Rather than single-key blocking, M-RESOLVER generates 8 complementary compound keys:
1. `NFULL`: First 3 normalized brand content tokens.
2. `N2` & `NSORT`: First 2 brand tokens and sorted token tuple.
3. `NCOMPACT`: First 7 alphanumeric characters (bridges domain names like `bonillapainting.com` $\leftrightarrow$ `Bonilla Painting`).
4. `PHON_ADDR`: **Soundex phonetic hash + primary address number** (e.g., `B636_5211` links `Brodrick's Financial` at `5211 Lincoln` to `Br0drick's Service` at `05211 Lincoln`).
5. `NAME_NUM`: Brand token + building/door number.
6. `ADDR_ANCHOR` & `ADDR_ANCHOR2`: Building/plot number + first & second street words.
7. `ADDR_CITY`: Building number + city/state token.
8. `GRAM_NUM`: Character 3-gram stem + building number.

### B. Structural Number Alignment
Address numbers have the highest information entropy in corporate records. The feature engine applies:
- **$+15.0$ Score Bonus** for identical building/plot numbers.
- **$-25.0$ Contradiction Penalty** for conflicting numbers (prevents wrong merges on identical street names).
- Neutral baseline ($0.0$) when numbers are absent.

### C. Open-World Country Partitioning (France Support)
Matches never cross country borders ($100\%$ verified empirically on 173,224 ground truth links). The pipeline adaptively normalizes:
- **French Corporate Forms:** `SARL`, `SAS`, `SA`, `EURL`, `SCI`, `SNC`, `Cie`, `Fils`.
- **French Street Abbreviations:** `R.` / `R` $\rightarrow$ `Rue`, `AV.` $\rightarrow$ `Avenue`, `BD.` $\rightarrow$ `Boulevard`, `ALL.` $\rightarrow$ `Allée`, `IMP.` $\rightarrow$ `Impasse`.

### D. Macro $F_{0.5}$ Precision Calibration
Because precision is weighted $2\times$ over recall:
$$F_{0.5} = \frac{1.25 \times \text{Precision} \times \text{Recall}}{0.25 \times \text{Precision} + \text{Recall}}$$
Ground truth reveals that entities have an average of **3.46 matches**, with $< 1\%$ exceeding 7. Over-predicting 15 candidates drops $F_{0.5}$ to $\approx 0.238$ due to precision penalties. By calibrating the decision threshold ($\tau = 78.0$) and capping predictions to the top 4 highest-confidence matches, precision increases to $> 75\%$, elevating $F_{0.5}$ by more than $3\times$.

---

## 4. Repository Structure

```
code/business_entity_resolution/
├── run.py                    # Master CLI runner (one-click reproduction)
├── requirements.txt          # Pinned runtime dependencies
├── README.md                 # System documentation & technical reference
└── src/
    ├── __init__.py           # Package init
    ├── normalize.py          # Multilingual text cleaning, Soundex, French & Indic normalization
    ├── blocking.py           # Multi-facet compound blocking & selectivity pruning
    ├── features.py           # RapidFuzz string metrics & structural number alignment
    ├── models.py             # LightGBM classifier & threshold optimizer
    ├── metrics.py            # Macro F_0.5, precision, recall, and singleton metrics
    ├── pipeline.py           # Full test set streaming pipeline
    ├── optimize_predictions.py # F_0.5 cardinality & precision calibration
    ├── graph_consistency.py  # Union-Find connected component post-processing
    ├── embedding_scorer.py   # Multilingual MiniLM cross-script semantic scorer
    ├── tfidf_blocker.py      # TF-IDF character n-gram blocking module
    └── lgbm_matcher.txt      # Trained LightGBM booster weights
```

---

## 5. Reproduction Instructions

### 1. Environment Setup
```bash
pip install -r requirements.txt
```

### 2. Execution
Run the complete pipeline from this directory:
```bash
python run.py --test-dir ../../student_resource/dataset/test --output-dir ../../student_resource/output
```

This generates:
- `matching_results.tsv` (Leaderboard submission)
- `candidate_pairs.tsv` (Candidate pairs)

### 3. Submission Validation
Run the official validator with strict ID-existence checking:
```bash
python ../../student_resource/utils/validate_submission.py \
    --matching ../../student_resource/output/matching_results.tsv \
    --candidate ../../student_resource/output/candidate_pairs.tsv \
    --test-dir ../../student_resource/dataset/test \
    --check-ids
```
**Expected Result:** `PASS — no blocking issues found. Safe to submit.`
