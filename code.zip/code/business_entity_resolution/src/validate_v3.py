"""
Validate pipeline_v3 logic on a training subset before running full test pipeline.
Measures: blocking recall, matching precision, matching recall, macro F_0.5.
"""
import csv, time, sys, os
sys.path.insert(0, 'code/business_entity_resolution')
sys.stdout.reconfigure(encoding='utf-8')

from collections import defaultdict
from src.pipeline_v3 import (
    clean_name, extract_addr_parts, extract_blocking_keys_v3,
    is_match, LEGAL_SUFFIXES
)

t0 = time.time()
N_S1 = 8000

# Load N_S1 train S1 records + ground truth
print(f"Loading {N_S1} S1 train records + ground truth...")
s1_data = {}
with open('student_resource/dataset/train/train_source1.tsv', 'r', encoding='utf-8', errors='replace') as f:
    r = csv.reader(f, delimiter='\t')
    next(r)
    for i, row in enumerate(r):
        name_c = clean_name(row[1])
        addr_c, nums, city_words = extract_addr_parts(row[2])
        s1_data[row[0]] = (name_c, addr_c, nums, row[3], name_c.split())
        if i >= N_S1: break

gt = {}
s23_needed = set()
with open('student_resource/dataset/train/train_ground_truth.tsv', 'r', encoding='utf-8', errors='replace') as f:
    r = csv.reader(f, delimiter='\t')
    next(r)
    for row in r:
        if row[0] in s1_data:
            ms = [m.strip() for m in row[1].split(',') if m.strip()] if len(row)>1 and row[1] else []
            gt[row[0]] = set(ms)
            s23_needed.update(ms)

print(f"Loaded: {len(s1_data):,} S1, {len(gt):,} with GT, {len(s23_needed):,} target S2/S3 in {time.time()-t0:.1f}s")

# Build S1 index
s1_index = defaultdict(list)
MAX_BUCKET = 60
for s1_id, rec in s1_data.items():
    country = rec[3]
    keys = extract_blocking_keys_v3(
        # reconstruct name from clean
        rec[0], rec[1]
    )
    for k in keys:
        bucket = s1_index[(country, k)]
        if len(bucket) < MAX_BUCKET:
            bucket.append(s1_id)

print(f"Index built: {len(s1_index):,} keys")

# Stream train_source2.tsv and check blocking recall
blocking_hits = defaultdict(set)
match_preds   = defaultdict(set)
comparisons   = 0

for src in ['train_source2.tsv', 'train_source3.tsv']:
    path = f'student_resource/dataset/train/{src}'
    src_rows = 0
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        r = csv.reader(f, delimiter='\t')
        next(r)
        for row in r:
            m_id, m_name, m_addr, m_country = row[0], row[1], row[2], row[3]
            if m_id not in s23_needed: continue  # only evaluate relevant records
            src_rows += 1

            m_name_c = clean_name(m_name)
            m_addr_c, m_nums, _ = extract_addr_parts(m_addr)
            m_keys = extract_blocking_keys_v3(m_name, m_addr)

            cand_s1 = set()
            for k in m_keys:
                bucket = s1_index.get((m_country, k))
                if bucket and len(bucket) <= MAX_BUCKET:
                    cand_s1.update(bucket)

            for s1_id in cand_s1:
                s1_name_c, s1_addr_c, s1_nums, _, _ = s1_data[s1_id]
                comparisons += 1
                blocking_hits[s1_id].add(m_id)
                matched, score = is_match(s1_name_c, s1_addr_c, s1_nums,
                                          m_name_c,  m_addr_c,  m_nums)
                if matched:
                    match_preds[s1_id].add(m_id)

    print(f"  {src}: processed {src_rows:,} target rows")

# Metrics
true_total  = sum(len(v) for v in gt.values())
blocking_recall_hits = sum(
    len(blocking_hits[s1] & gt[s1]) for s1 in gt if gt[s1]
)
match_tp = sum(len(match_preds[s1] & gt[s1]) for s1 in gt)
match_fp = sum(len(match_preds[s1] - gt[s1]) for s1 in gt)
match_fn = sum(len(gt[s1] - match_preds[s1]) for s1 in gt)

blocking_recall = blocking_recall_hits / true_total if true_total else 0
match_precision = match_tp / (match_tp + match_fp) if (match_tp+match_fp) > 0 else 0
match_recall    = match_tp / (match_tp + match_fn) if (match_tp+match_fn) > 0 else 0
f05 = (1.25 * match_precision * match_recall) / (0.25 * match_precision + match_recall + 1e-9)

print(f"\n{'='*55}")
print(f"VALIDATION RESULTS (N_S1={N_S1:,})")
print(f"{'='*55}")
print(f"True matches total:       {true_total:,}")
print(f"Blocking recall:          {blocking_recall*100:.2f}%  ({blocking_recall_hits:,}/{true_total:,})")
print(f"Comparisons made:         {comparisons:,}")
print(f"Match TP:                 {match_tp:,}")
print(f"Match FP:                 {match_fp:,}")
print(f"Match FN:                 {match_fn:,}")
print(f"Match Precision:          {match_precision*100:.2f}%")
print(f"Match Recall:             {match_recall*100:.2f}%")
print(f"Macro F_0.5 (estimate):   {f05:.4f}")
print(f"Wall-clock time:          {time.time()-t0:.1f}s")
print(f"{'='*55}")
