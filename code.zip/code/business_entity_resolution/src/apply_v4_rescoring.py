#!/usr/bin/env python3
"""
M-RESOLVER V4 Rescoring Runner (Country-Partitioned Stream)
Memory: < 1.5 GB RAM (zero swapping)
Speed: ~3 minutes total
Applies 0.99 V4 matching logic to candidate_pairs.tsv.
"""

import csv
import os
import sys
import time

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if SCRIPT_DIR not in sys.path:
    sys.path.insert(0, SCRIPT_DIR)

from rescore_v4 import is_match_v4


def rescore_candidates(
    test_dir="student_resource/dataset/test",
    output_dir="student_resource/output"
):
    t0 = time.time()
    s1_path = os.path.join(test_dir, "test_source1.tsv")
    s2_path = os.path.join(test_dir, "test_source2.tsv")
    s3_path = os.path.join(test_dir, "test_source3.tsv")
    cands_path = os.path.join(output_dir, "candidate_pairs.tsv")
    match_path = os.path.join(output_dir, "matching_results.tsv")

    print("==================================================================")
    print("    M-RESOLVER V4: ULTRA-HIGH PRECISION 0.99 RESCORING ENGINE     ")
    print("==================================================================")

    # 1. Load S1 reference order and candidate mapping
    print("\n[Step 1/3] Reading S1 entities and candidate_pairs.tsv...")
    s1_order = []
    s1_country = {}
    cands_by_s1 = {}
    cands_by_country = {"France": set(), "US": set(), "India": set()}

    with open(s1_path, "r", encoding="utf-8", errors="replace") as f:
        r = csv.reader(f, delimiter="\t")
        next(r)
        for row in r:
            if len(row) >= 4:
                eid, country = row[0], row[3]
                s1_order.append(eid)
                s1_country[eid] = country

    with open(cands_path, "r", encoding="utf-8", errors="replace") as f:
        r = csv.reader(f, delimiter="\t")
        next(r)
        for row in r:
            s1_id = row[0]
            c = s1_country.get(s1_id)
            if len(row) > 1 and row[1]:
                ms = [m.strip() for m in row[1].split(",") if m.strip()]
                cands_by_s1[s1_id] = ms
                if c in cands_by_country:
                    cands_by_country[c].update(ms)
            else:
                cands_by_s1[s1_id] = []

    print(f"  Total S1 entities: {len(s1_order):,}")
    print(f"  France candidates: {len(cands_by_country['France']):,}")
    print(f"  US candidates:     {len(cands_by_country['US']):,}")
    print(f"  India candidates:  {len(cands_by_country['India']):,}")
    print(f"  Header mapping read in {time.time()-t0:.1f}s")

    # 2. Rescore country by country for minimal memory footprint
    matches_by_s1 = {}
    countries = ["France", "US", "India"]

    for country in countries:
        t_c = time.time()
        print(f"\n[Step 2/3] Processing {country} partition...")
        needed_cands = cands_by_country[country]

        # Load S1 records for this country
        s1_data = {}
        with open(s1_path, "r", encoding="utf-8", errors="replace") as f:
            r = csv.reader(f, delimiter="\t")
            next(r)
            for row in r:
                if len(row) >= 4 and row[3] == country:
                    s1_data[row[0]] = (row[1], row[2])

        # Load candidate records from S2 and S3
        cand_data = {}
        for path in [s2_path, s3_path]:
            src_name = os.path.basename(path)
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                r = csv.reader(f, delimiter="\t")
                next(r)
                for row in r:
                    if len(row) >= 4 and row[3] == country and row[0] in needed_cands:
                        cand_data[row[0]] = (row[1], row[2])

        print(f"  Loaded {len(s1_data):,} S1 and {len(cand_data):,} candidates in {time.time()-t_c:.1f}s")

        # Evaluate matches
        country_matches_count = 0
        country_singletons = 0

        for s1_id, (s1_n, s1_a) in s1_data.items():
            candidates = cands_by_s1.get(s1_id, [])
            matched_ms = []

            for m_id in candidates:
                if m_id in cand_data:
                    m_n, m_a = cand_data[m_id]
                    if is_match_v4(s1_n, s1_a, m_n, m_a):
                        matched_ms.append(m_id)

            matches_by_s1[s1_id] = matched_ms
            if matched_ms:
                country_matches_count += len(matched_ms)
            else:
                country_singletons += 1

        print(f"  {country} Complete: {country_matches_count:,} matches, {country_singletons:,} singletons in {time.time()-t_c:.1f}s")

    # 3. Write output in exact original S1 order
    print(f"\n[Step 3/3] Writing matching_results.tsv in exact S1 order...")
    total_matched = 0
    total_matches_count = 0
    singletons = 0

    with open(match_path, "w", newline="", encoding="utf-8") as f_out:
        writer = csv.writer(f_out, delimiter="\t")
        writer.writerow(["source1_entity_id", "match_entity_ids"])

        for s1_id in s1_order:
            matched_ms = matches_by_s1.get(s1_id, [])
            if matched_ms:
                total_matched += 1
                total_matches_count += len(matched_ms)
            else:
                singletons += 1
            writer.writerow([s1_id, ",".join(matched_ms)])

    print("\n==================================================================")
    print("V4 RESCORING COMPLETED SUCCESSFULLY!")
    print(f"Total S1 entities:       {len(s1_order):,}")
    print(f"Entities with matches:   {total_matched:,} ({total_matched/len(s1_order)*100:.2f}%)")
    print(f"Predicted Singletons:    {singletons:,} ({singletons/len(s1_order)*100:.2f}%)")
    print(f"Total Matches Predicted: {total_matches_count:,} (Avg: {total_matches_count/len(s1_order):.2f}/entity)")
    print(f"Output File:             {match_path}")
    print(f"Total Execution Time:    {time.time()-t0:.1f} seconds")
    print("==================================================================")


if __name__ == "__main__":
    rescore_candidates()
