import csv
import time
import sys
import heapq
import numpy as np
import lightgbm as lgb
from collections import defaultdict
from rapidfuzz import fuzz

try:
    from .normalize import normalize_name, normalize_address, soundex, is_indic_non_ascii
    from .blocking import extract_blocking_keys
    from .graph_consistency import apply_graph_consistency, apply_singleton_protection
    from .metrics import evaluate_predictions
except ImportError:
    from src.normalize import normalize_name, normalize_address, soundex, is_indic_non_ascii
    from src.blocking import extract_blocking_keys
    from src.graph_consistency import apply_graph_consistency, apply_singleton_protection
    from src.metrics import evaluate_predictions

sys.stdout.reconfigure(encoding='utf-8')
t0 = time.time()

# Load trained LightGBM booster
booster = lgb.Booster(model_file='code/business_entity_resolution/src/lgbm_matcher.txt')
print('Loaded LightGBM model successfully.')

# Load 5000 S1 validation records
N = 5000
s1_records = {}
s1_country = {}
gt = {}

with open('student_resource/dataset/train/train_source1.tsv', 'r', encoding='utf-8', errors='ignore') as f:
    r = csv.reader(f, delimiter='\t')
    next(r)
    for i, row in enumerate(r):
        n_clean, n_toks = normalize_name(row[1])
        a_clean, a_words, a_nums = normalize_address(row[2])
        keys = extract_blocking_keys(row[1], row[2])
        s1_records[row[0]] = (n_clean, n_toks, a_clean, a_nums, row[3], row[1], keys)
        s1_country[row[0]] = row[3]
        if i >= N:
            break

with open('student_resource/dataset/train/train_ground_truth.tsv', 'r', encoding='utf-8', errors='ignore') as f:
    r = csv.reader(f, delimiter='\t')
    next(r)
    for row in r:
        if row[0] in s1_records:
            ms = [m.strip() for m in row[1].split(',') if m.strip()] if len(row) > 1 and row[1] else []
            gt[row[0]] = set(ms)

# Index S1
s1_index = defaultdict(list)
for s1_id, rec in s1_records.items():
    country = rec[4]
    for k in rec[6]:
        s1_index[(country, k)].append(s1_id)

print(f'Indexed {len(s1_records)} S1 with {len(s1_index):,} keys in {time.time()-t0:.1f}s')

def get_features(s1_rec, m_rec):
    s1_n, s1_toks, s1_a, s1_nums, country, s1_raw, _ = s1_rec
    m_n, m_toks, m_a, m_nums, _, m_raw, _ = m_rec

    n_ratio = fuzz.ratio(s1_n, m_n) / 100.0
    n_sort = fuzz.token_sort_ratio(s1_n, m_n) / 100.0
    n_set = fuzz.token_set_ratio(s1_n, m_n) / 100.0

    if s1_a and m_a:
        a_sort = fuzz.token_sort_ratio(s1_a, m_a) / 100.0
        a_set = fuzz.token_set_ratio(s1_a, m_a) / 100.0
    else:
        a_sort = 0.5
        a_set = 0.5

    if s1_nums and m_nums:
        num_m = 1.0 if (set(s1_nums) & set(m_nums)) else 0.0
    else:
        num_m = 0.5

    comb_set = fuzz.token_set_ratio(f'{s1_n} {s1_a}', f'{m_n} {m_a}') / 100.0
    first_w = 1.0 if (s1_toks and m_toks and s1_toks[0] == m_toks[0]) else 0.0

    snd1 = soundex(s1_toks[0]) if s1_toks else ''
    snd2 = soundex(m_toks[0]) if m_toks else ''
    snd_m = 1.0 if (snd1 and snd2 and snd1 == snd2) else 0.0

    l1, l2 = len(s1_n), len(m_n)
    len_r = min(l1, l2) / max(l1, l2) if max(l1, l2) > 0 else 1.0
    cross_script = 1.0 if (is_indic_non_ascii(s1_raw) != is_indic_non_ascii(m_raw)) else 0.0

    return [n_ratio, n_sort, n_set, a_sort, a_set, num_m, comb_set, first_w, snd_m, len_r, cross_script]

# Stream S2
candidates = defaultdict(list)
TOP_K = 15

with open('student_resource/dataset/train/train_source2.tsv', 'r', encoding='utf-8', errors='ignore') as f:
    r = csv.reader(f, delimiter='\t')
    next(r)
    for i, row in enumerate(r):
        m_id, name, addr, country = row[0], row[1], row[2], row[3]
        keys = extract_blocking_keys(name, addr)
        matched_s1 = set()
        for k in keys:
            s1s = s1_index.get((country, k))
            if s1s and len(s1s) <= 40:
                matched_s1.update(s1s)

        if matched_s1:
            n_clean, n_toks = normalize_name(name)
            a_clean, a_words, a_nums = normalize_address(addr)
            m_rec = (n_clean, n_toks, a_clean, a_nums, country, name, keys)

            for s1 in matched_s1:
                feats = get_features(s1_records[s1], m_rec)
                if feats[6] >= 0.35 or feats[5] == 1.0:
                    prob = float(booster.predict([feats])[0])
                    if prob >= 0.30:
                        heap = candidates[s1]
                        if len(heap) < TOP_K:
                            heapq.heappush(heap, (prob, m_id))
                        elif prob > heap[0][0]:
                            heapq.heapreplace(heap, (prob, m_id))

        if i >= 1500000:
            break

print(f'Streamed 1.5M rows in {time.time()-t0:.1f}s')

print('=== EVALUATION OF COUNTRY-ADAPTIVE THRESHOLDS & GRAPH CONSISTENCY ===')
for thresh_us in [0.65, 0.70, 0.75]:
    for thresh_in in [0.50, 0.55, 0.60]:
        raw_preds = defaultdict(set)
        probs = {}
        for s1, heap in candidates.items():
            c = s1_country[s1]
            t = thresh_in if c == 'India' else thresh_us
            for p, m in heap:
                probs[(s1, m)] = p
                if p >= t:
                    raw_preds[s1].add(m)

        refined = apply_singleton_protection(raw_preds, probs, high_precision_threshold=0.75)
        refined = apply_graph_consistency(refined, probs, min_cluster_prob=0.60)

        eval_res = evaluate_predictions(refined, gt)
        f05 = eval_res['macro_f05']
        p = eval_res['macro_precision']
        r = eval_res['macro_recall']
        sing = eval_res['singleton_accuracy'] * 100.0
        print(f'US={thresh_us:.2f}, IN={thresh_in:.2f} -> Macro F0.5: {f05:.4f} | Prec: {p:.4f} | Rec: {r:.4f} | Singletons: {sing:.1f}%')
