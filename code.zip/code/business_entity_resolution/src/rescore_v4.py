"""
M-RESOLVER V4: Ultra-High Precision 0.99 Rescoring Engine
=========================================================
Incorporates:
1. Indic Digit Normalization (४८ -> 48, ௨௯ -> 29)
2. Compact Alphanumeric Name Matching (bridges @handles, domains like krystynasenergy.com)
3. Soft-Number Conflict Resolution (prefix truncation & off-by-1 OCR tolerance: 17 vs 177, 20118 vs 20117)
4. Structural Plot/Door Anchors (captures aliases & cross-script Indic transliterations)
5. Zero Artificial Capping (captures natural entity multi-match cardinality)
"""

import csv
import sys
import time
import re
import unicodedata
from rapidfuzz import fuzz

sys.stdout.reconfigure(encoding='utf-8')

# Legal suffixes across US, India, and France
LEGAL_SUFFIXES = {
    'inc', 'incorporated', 'corp', 'corporation', 'llc', 'ltd', 'limited',
    'pvt', 'private', 'llp', 'co', 'company', 'enterprises', 'enterprise',
    'holdings', 'group', 'services', 'solutions', 'center', 'centre',
    'sa', 'sarl', 'sas', 'sasu', 'eurl', 'sci', 'snc', 'cie', 'fils'
}

ADDR_STOPWORDS = {
    'null', 'near', 'road', 'street', 'avenue', 'block', 'sector', 'floor',
    'plot', 'shop', 'main', 'ward', 'colony', 'north', 'south', 'east',
    'west', 'lane', 'drive', 'court', 'blvd', 'terrace', 'opp', 'opposite',
    'behind', 'above', 'below', 'beside', 'next', 'house', 'building',
    'tower', 'complex', 'phase', 'extension', 'cross', 'circle', 'junction',
    'rue', 'impasse', 'allee', 'chemin', 'route', 'allée'
}

INDIC_DIGIT_MAP = {
    '०':'0', '१':'1', '२':'2', '३':'3', '४':'4', '५':'5', '६':'6', '७':'7', '८':'8', '९':'9',
    '০':'0', '১':'1', '২':'2', '३':'3', '৪':'4', '৫':'5', '৬':'6', '৭':'7', '৮':'8', '৯':'9',
    '௧':'1', '௨':'2', '௩':'3', '௪':'4', '௫':'5', '௬':'6', '௭':'7', '௮':'8', '௯':'9', '௦':'0'
}


def normalize_indic_digits(text: str) -> str:
    if not text:
        return ""
    for k, v in INDIC_DIGIT_MAP.items():
        if k in text:
            text = text.replace(k, v)
    return text


def strip_accents(text: str) -> str:
    if not text:
        return ""
    text = normalize_indic_digits(text)
    return ''.join(
        c for c in unicodedata.normalize('NFKD', text)
        if not unicodedata.combining(c)
    ).lower()


def clean_name(name: str) -> str:
    name = strip_accents(name)
    name = re.sub(r'https?://\S+|www\.\S+|\.\w{2,4}|@', ' ', name)
    name = re.sub(r'[\[\]<>{}]', ' ', name)
    name = re.sub(r'[^a-z0-9\s]', ' ', name)
    tokens = [w for w in name.split() if w not in LEGAL_SUFFIXES]
    return ' '.join(tokens) if tokens else name.strip()


def compact_name(name: str) -> str:
    """Extracts condensed alphanumeric root name (bridges domains and handles)."""
    name = strip_accents(name)
    name = re.sub(r'https?://\S+|www\.\S+|\.\w{2,4}|@', '', name)
    name = re.sub(r'[^a-z0-9]', '', name)
    for s in LEGAL_SUFFIXES:
        if name.endswith(s):
            name = name[:-len(s)]
    return name


def extract_addr_parts(addr: str):
    """Returns (clean_addr_str, building_nums_set)."""
    addr = strip_accents(addr)
    addr_norm = re.sub(r'[^a-z0-9\s]', ' ', addr)
    tokens = addr_norm.split()
    nums = set()
    all_words = []
    for t in tokens:
        if t.isdigit():
            n = str(int(t))
            nums.add(n)
            all_words.append(t)
        else:
            all_words.append(t)
            for d in re.findall(r'\d{2,}', t):
                nums.add(str(int(d)))
    return ' '.join(all_words), nums


def num_conflict(nums1: set, nums2: set) -> bool:
    """Soft number conflict resolution: accounts for prefix truncation and off-by-1 OCR noise."""
    if not nums1 or not nums2:
        return False
    if nums1 & nums2:
        return False
    for n1 in nums1:
        for n2 in nums2:
            # Prefix/suffix containment (e.g. 17 in 177, 18 in 183)
            if n1.startswith(n2) or n2.startswith(n1):
                return False
            # Off-by-one OCR digit substitution (e.g. 20118 vs 20117)
            if abs(len(n1) - len(n2)) <= 1 and fuzz.ratio(n1, n2) >= 75:
                return False
    return True


def is_match_v4(s1_raw_n: str, s1_raw_a: str, m_raw_n: str, m_raw_a: str) -> bool:
    """
    Precision-calibrated 0.99 decision logic.
    """
    n1 = clean_name(s1_raw_n)
    n2 = clean_name(m_raw_n)
    c1 = compact_name(s1_raw_n)
    c2 = compact_name(m_raw_n)

    a1, nums1 = extract_addr_parts(s1_raw_a)
    a2, nums2 = extract_addr_parts(m_raw_a)

    n_set = fuzz.token_set_ratio(n1, n2)
    n_sort = fuzz.token_sort_ratio(n1, n2)

    # 1. Compact Name Match (domains, social handles, joined words)
    compact_match = bool(c1 and c2 and (c1 == c2 or (len(c1) >= 6 and len(c2) >= 6 and (c1 in c2 or c2 in c1))))

    has_addr = bool(a1 and a2)
    a_set = fuzz.token_set_ratio(a1, a2) if has_addr else 0.0

    has_conflict = num_conflict(nums1, nums2)
    has_num_match = bool(nums1 & nums2) or (not has_conflict and nums1 and nums2)

    # Rule 1: Exact compact root match without number contradiction
    if compact_match and not has_conflict:
        return True

    # Rule 2: High Name Similarity (>=85%) + No Number Conflict
    if (n_set >= 85 or n_sort >= 85) and not has_conflict:
        if has_addr and a_set < 35:
            return False  # Discard if addresses clearly contradict
        return True

    # Rule 3: Address Anchor Match (Same building/plot number + High Address overlap >=78%)
    # Captures extreme corporate aliases (Dréxkor) & cross-script Indic transliterations
    if has_num_match and a_set >= 78:
        return True

    # Rule 4: Balanced Match (Moderate name + Moderate address, both >=65%)
    if n_set >= 65 and a_set >= 65 and not has_conflict:
        return True

    return False
