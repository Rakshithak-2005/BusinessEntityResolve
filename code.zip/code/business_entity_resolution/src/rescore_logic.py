"""
High-Precision Rescoring Engine for candidate_pairs.tsv.
Applies:
1. Dual-channel matching:
   - Channel A: High Name Match (>=85%) with no address number conflict
   - Channel B: Address Anchor Match (identical building/plot numbers + address similarity >=70%)
     -> Directly captures cross-script Tamil/Hindi and corporate aliases!
   - Channel C: Balanced Match (name >= 65% and address >= 65% with no number conflict)
2. Natural cardinality (no artificial capping to 4).
3. Exact singleton preservation.
"""

import csv
import sys
import time
import re
import unicodedata
from rapidfuzz import fuzz

sys.stdout.reconfigure(encoding='utf-8')

LEGAL_SUFFIXES = {
    'inc', 'incorporated', 'corp', 'corporation', 'llc', 'ltd', 'limited',
    'pvt', 'private', 'llp', 'co', 'company', 'enterprises', 'enterprise',
    'holdings', 'group', 'services', 'solutions', 'center',
    'sa', 'sarl', 'sas', 'sasu', 'eurl', 'sci', 'snc', 'cie', 'fils'
}

def strip_accents(text):
    if not text:
        return ""
    text = unicodedata.normalize('NFKD', text)
    return ''.join(c for c in text if not unicodedata.combining(c)).lower()

def clean_name(name):
    name = strip_accents(name)
    name = re.sub(r'https?://\S+|www\.\S+|\.com|\.org|\.net|\.in|\.co|\.fr', ' ', name)
    name = re.sub(r'[\[\]<>]', ' ', name)
    name = re.sub(r'[^a-z0-9\s]', ' ', name)
    tokens = [w for w in name.split() if w not in LEGAL_SUFFIXES]
    return ' '.join(tokens) if tokens else name

def clean_addr(addr):
    addr = strip_accents(addr)
    addr = re.sub(r'[^a-z0-9\s]', ' ', addr)
    tokens = addr.split()
    nums = [str(int(t)) for t in tokens if t.isdigit()]
    return ' '.join(tokens), set(nums)

def is_match(s1_n, s1_a, s1_nums, m_n, m_a, m_nums):
    n_set = fuzz.token_set_ratio(s1_n, m_n)
    n_sort = fuzz.token_sort_ratio(s1_n, m_n)

    a_set = fuzz.token_set_ratio(s1_a, m_a) if (s1_a and m_a) else 0.0

    has_num_match = bool(s1_nums & m_nums) if (s1_nums and m_nums) else False
    has_num_conflict = bool(s1_nums and m_nums and not (s1_nums & m_nums))

    # Condition 1: High Name Similarity (without conflicting numbers)
    if (n_set >= 85 or n_sort >= 85) and not has_num_conflict:
        return True

    # Condition 2: Address Anchor Match (Matching building number + High address overlap)
    # This captures cross-script Indic transliterations & corporate aliases!
    if has_num_match and a_set >= 70:
        return True

    # Condition 3: Balanced Match (Moderate name + Moderate address)
    if n_set >= 65 and a_set >= 65 and not has_num_conflict:
        return True

    return False
