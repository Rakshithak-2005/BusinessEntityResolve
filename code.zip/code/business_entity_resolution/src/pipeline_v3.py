"""
M-RESOLVER V3 Pipeline — Full Production Streaming Engine
=========================================================
Key improvements over V1:
1. CITY+NUMBER blocking keys: (building_number, city_word) pairs catch
   extreme aliases like "Dréxkor" at "85 Wanye Ave, Ticonderoga" matching
   "Maure Williams Colombier" at "85 Wayne Ave, Ticonderoga, NY"
2. No name-based pre-filter: All candidate pairs from blocking are scored,
   regardless of name similarity (catches cross-script & extreme OCR noise)
3. Dual-channel matching:
   - Channel A: High name similarity (>=85%) + no address number conflict
   - Channel B: Shared building/plot number + high address similarity (>=70%)
   - Channel C: Balanced name + address similarity (both >=65%, no num conflict)
4. Natural cardinality: No artificial top-K cap; match all truly matching records
"""

import csv
import heapq
import os
import re
import sys
import time
import unicodedata
from collections import defaultdict

try:
    from rapidfuzz import fuzz
except ImportError:
    raise ImportError("rapidfuzz is required: pip install rapidfuzz")


# ─── Text Normalization ────────────────────────────────────────────────────────

LEGAL_SUFFIXES = {
    'inc', 'incorporated', 'corp', 'corporation', 'llc', 'ltd', 'limited',
    'pvt', 'private', 'llp', 'co', 'company', 'enterprises', 'enterprise',
    'holdings', 'group', 'services', 'solutions', 'center', 'centre',
    'sa', 'sarl', 'sas', 'sasu', 'eurl', 'sci', 'snc', 'cie', 'fils',
    'associates', 'technologies', 'international'
}

ADDR_STOPWORDS = {
    'null', 'near', 'road', 'street', 'avenue', 'block', 'sector', 'floor',
    'plot', 'shop', 'main', 'ward', 'colony', 'north', 'south', 'east',
    'west', 'lane', 'drive', 'court', 'blvd', 'terrace', 'opp', 'opposite',
    'behind', 'above', 'below', 'beside', 'next', 'house', 'building',
    'tower', 'complex', 'phase', 'extension', 'cross', 'circle', 'junction',
    # French stopwords
    'rue', 'impasse', 'allee', 'chemin', 'route', 'allée',
}


def strip_accents(text: str) -> str:
    if not text:
        return ""
    return ''.join(
        c for c in unicodedata.normalize('NFKD', text)
        if not unicodedata.combining(c)
    ).lower()


def clean_name(name: str) -> str:
    name = strip_accents(name)
    name = re.sub(r'https?://\S+|www\.\S+|\.\w{2,4}', ' ', name)
    name = re.sub(r'[\[\]<>{}]', ' ', name)
    name = re.sub(r'[^a-z0-9\s]', ' ', name)
    tokens = [w for w in name.split() if w not in LEGAL_SUFFIXES]
    return ' '.join(tokens) if tokens else name.strip()


def extract_addr_parts(addr: str):
    """Returns (clean_addr_str, building_nums_set, city_words_list).
    Also extracts alphanumeric plot codes (D220, AF-684, Shop-04) and near-miss number variants.
    """
    addr = strip_accents(addr)
    addr_norm = re.sub(r'[^a-z0-9\s]', ' ', addr)
    tokens = addr_norm.split()
    nums = set()
    city_words = []
    all_words = []
    for t in tokens:
        if t.isdigit():
            n = str(int(t))
            nums.add(n)
            # Near-miss: strip last digit of long numbers (20118→2011, catches off-by-one OCR)
            if len(n) >= 4:
                nums.add(n[:-1])
            all_words.append(t)
        else:
            all_words.append(t)
            if len(t) >= 4 and t not in ADDR_STOPWORDS:
                city_words.append(t)
            # Extract embedded digits from alphanumeric codes: d220→220, af684→684
            for d in re.findall(r'\d{2,}', t):
                nums.add(str(int(d)))
    clean = ' '.join(all_words)
    return clean, nums, city_words


def soundex(token: str) -> str:
    if not token or not token[0].isalpha():
        return ""
    token = token.upper()
    mapping = {'BFPV': '1', 'CGJKQSXZ': '2', 'DT': '3', 'L': '4', 'MN': '5', 'R': '6'}
    code = [token[0]]
    for c in token[1:]:
        for keys, val in mapping.items():
            if c in keys:
                if val != code[-1]:
                    code.append(val)
                break
    return (''.join(code) + '0000')[:4]


# ─── Matching Logic ────────────────────────────────────────────────────────────

def is_match(s1_name_c: str, s1_addr_c: str, s1_nums: set,
             m_name_c: str,  m_addr_c: str,  m_nums: set) -> tuple[bool, float]:
    """
    Precision-tuned tri-channel matching. Returns (is_match, confidence_score).

    Channel A: High name similarity + no address number conflict
               + address sanity check (not clearly different locations)
    Channel B: Shared building/plot number + STRONG address similarity (>=82%)
               Catches extreme aliases (Dréxkor), cross-script Indic transliterations
    Channel C: Balanced moderate name + address (both >=68%, no num conflict)
    """
    n_set  = fuzz.token_set_ratio(s1_name_c, m_name_c)
    n_sort = fuzz.token_sort_ratio(s1_name_c, m_name_c)

    has_addr = bool(s1_addr_c and m_addr_c)
    a_set = fuzz.token_set_ratio(s1_addr_c, m_addr_c) if has_addr else 0.0

    has_num_match    = bool(s1_nums & m_nums) if (s1_nums and m_nums) else False
    has_num_conflict = bool(s1_nums and m_nums and not (s1_nums & m_nums))

    # Channel A: Strong name match (>=85%) + no address conflict
    # Additional guard: if both have addresses, they must not be clearly different (a_set >= 40)
    if (n_set >= 85 or n_sort >= 85) and not has_num_conflict:
        if has_addr and a_set < 40:
            pass  # clearly different locations — reject
        else:
            score = (n_set + n_sort) / 2 + (a_set * 0.2)
            return True, score

    # Channel B: Shared building number + STRONG address overlap (raised to 82%)
    # High threshold filters different tenants in same building (FP), while
    # keeping genuine same-entity pairs where addresses are near-identical
    if has_num_match and a_set >= 82:
        score = a_set + (n_set * 0.1)
        return True, score

    # Channel C: Balanced name + address (both >=68%, no conflict)
    if n_set >= 68 and a_set >= 68 and not has_num_conflict:
        score = n_set * 0.5 + a_set * 0.5
        return True, score

    return False, 0.0


# ─── Blocking Key Extraction ───────────────────────────────────────────────────

def extract_blocking_keys_v3(name: str, address: str) -> list[tuple[str, str]]:
    """Generates multi-facet blocking keys including city+number anchors."""
    name_c = clean_name(name)
    name_tokens = [w for w in name_c.split() if len(w) >= 2]
    _, nums, city_words = extract_addr_parts(address)

    keys = []
    # Use longest numbers first (more specific / less common)
    sorted_nums = sorted(nums, key=lambda x: -len(x))

    # 1. Full 3-token name key
    if name_tokens:
        keys.append(('NFULL', '_'.join(name_tokens[:3])))

    # 2. 2-token name pairs and sorted
    if len(name_tokens) >= 2:
        keys.append(('N2',    f"{name_tokens[0]}_{name_tokens[1]}"))
        keys.append(('NSORT', '_'.join(sorted(name_tokens[:2]))))

    # 3. Single-word key for short names
    if len(name_tokens) == 1 and len(name_tokens[0]) >= 4:
        keys.append(('N1', name_tokens[0]))

    # 4. ** N_2ND: second word of name alone — catches honorific prefixes (Sri/Dr/Shri) **
    if len(name_tokens) >= 2 and len(name_tokens[1]) >= 5:
        keys.append(('N_2ND', name_tokens[1]))
        if sorted_nums:
            keys.append(('N2ND_NUM', f"{name_tokens[1]}_{sorted_nums[0]}"))

    # 5. Compact alphanumeric prefix (bridges domain URLs and OCR fusions)
    compact = ''.join(name_tokens)
    if len(compact) >= 5:
        keys.append(('NCOMPACT', compact[:7]))

    # 6. Phonetic Soundex + address number
    if name_tokens and sorted_nums:
        snd = soundex(name_tokens[0])
        if snd:
            keys.append(('PHON_ADDR', f"{snd}_{sorted_nums[0]}"))

    # 7. Brand token + primary (longest) number
    if name_tokens and sorted_nums:
        keys.append(('NAME_NUM', f"{name_tokens[0]}_{sorted_nums[0]}"))

    # 8. *** CITY + NUMBER ANCHORS *** (catches Dréxkor & cross-script!)
    # Use longest numbers (most specific) with distinctive city words
    for city in city_words[:5]:
        for num in sorted_nums[:2]:
            keys.append(('CITY_NUM', f"{city}_{num}"))

    # 9. ** Soundex-City + number: catches city-name typos (visakhapatnam vs vishakhapatnam) **
    for city in city_words[:3]:
        if len(city) >= 5:
            snd_city = soundex(city)
            if snd_city and sorted_nums:
                keys.append(('SNDCITY_NUM', f"{snd_city}_{sorted_nums[0]}"))

    # 10. City + brand token
    if name_tokens and city_words:
        keys.append(('CITY_BRAND', f"{city_words[0]}_{name_tokens[0]}"))


    return keys


# ─── Main Pipeline ─────────────────────────────────────────────────────────────

def run_pipeline_v3(
    test_dir: str,
    output_dir: str,
    max_bucket_size: int = 80,
):
    os.makedirs(output_dir, exist_ok=True)
    t0 = time.time()

    s1_path  = os.path.join(test_dir, 'test_source1.tsv')
    s2_path  = os.path.join(test_dir, 'test_source2.tsv')
    s3_path  = os.path.join(test_dir, 'test_source3.tsv')
    match_out = os.path.join(output_dir, 'matching_results.tsv')
    cands_out = os.path.join(output_dir, 'candidate_pairs.tsv')

    # ── Step 1: Index all S1 records ─────────────────────────────────────────
    print(f"[V3] Step 1: Indexing Source 1 records…")
    s1_data   = {}   # id → (name_c, addr_c, nums, city_words, country, name_raw, addr_raw)
    s1_index  = defaultdict(list)   # (country, key_type, key_val) → [s1_ids]

    with open(s1_path, 'r', encoding='utf-8', errors='replace') as f:
        reader = csv.reader(f, delimiter='\t')
        next(reader)
        for row in reader:
            if len(row) < 4:
                continue
            eid, name, addr, country = row[0], row[1], row[2], row[3]
            name_c = clean_name(name)
            addr_c, nums, city_words = extract_addr_parts(addr)
            name_tokens = name_c.split()
            s1_data[eid] = (name_c, addr_c, nums, country, name_tokens)

            keys = extract_blocking_keys_v3(name, addr)
            for k in keys:
                bucket = s1_index[(country, k)]
                if len(bucket) < max_bucket_size:
                    bucket.append(eid)

    print(f"  Indexed {len(s1_data):,} S1 records | "
          f"{len(s1_index):,} keys | {time.time()-t0:.1f}s")

    # ── Step 2: Stream S2 & S3, build candidates & match ─────────────────────
    print(f"[V3] Step 2: Streaming Source 2 & 3…")

    all_matches   = defaultdict(set)   # s1_id → set of matched m_ids
    all_candidates = defaultdict(set)  # s1_id → set of candidate m_ids

    total_comparisons = 0
    total_matches_found = 0

    for src_path in [s2_path, s3_path]:
        src_name = os.path.basename(src_path)
        print(f"  Processing {src_name}…")
        src_t = time.time()
        rows_processed = 0

        with open(src_path, 'r', encoding='utf-8', errors='replace') as f:
            reader = csv.reader(f, delimiter='\t')
            next(reader)

            for row in reader:
                if len(row) < 4:
                    continue
                m_id, m_name, m_addr, m_country = row[0], row[1], row[2], row[3]
                rows_processed += 1

                # Normalize
                m_name_c = clean_name(m_name)
                m_addr_c, m_nums, m_city_words = extract_addr_parts(m_addr)

                # Get blocking keys
                m_keys = extract_blocking_keys_v3(m_name, m_addr)

                # Find candidate S1 entities
                cand_s1 = set()
                for k in m_keys:
                    bucket = s1_index.get((m_country, k))
                    if bucket and len(bucket) <= max_bucket_size:
                        cand_s1.update(bucket)

                if not cand_s1:
                    continue

                # Score each candidate pair
                for s1_id in cand_s1:
                    s1_name_c, s1_addr_c, s1_nums, _, s1_toks = s1_data[s1_id]
                    total_comparisons += 1

                    # Register as candidate
                    all_candidates[s1_id].add(m_id)

                    # Apply dual-channel matching
                    matched, score = is_match(
                        s1_name_c, s1_addr_c, s1_nums,
                        m_name_c,  m_addr_c,  m_nums
                    )
                    if matched:
                        all_matches[s1_id].add(m_id)
                        total_matches_found += 1

                if rows_processed % 500_000 == 0:
                    elapsed = time.time() - src_t
                    rate = rows_processed / elapsed
                    print(f"    {rows_processed:,} rows | {rate:,.0f} rows/s | "
                          f"matches so far: {total_matches_found:,} | "
                          f"t={elapsed:.0f}s")

        print(f"  {src_name}: {rows_processed:,} rows in {time.time()-src_t:.1f}s")

    # ── Step 3: Write outputs ─────────────────────────────────────────────────
    print(f"[V3] Step 3: Writing outputs…")
    write_t = time.time()

    with open(match_out, 'w', newline='', encoding='utf-8') as fm, \
         open(cands_out, 'w', newline='', encoding='utf-8') as fc:

        fw_m = csv.writer(fm, delimiter='\t')
        fw_c = csv.writer(fc, delimiter='\t')
        fw_m.writerow(['source1_entity_id', 'match_entity_ids'])
        fw_c.writerow(['source1_entity_id', 'candidate_entity_ids'])

        for s1_id in s1_data:
            matches   = sorted(all_matches.get(s1_id, set()))
            candidates = sorted(all_candidates.get(s1_id, set()))

            # Ensure matches ⊆ candidates (competition constraint)
            for m in matches:
                if m not in all_candidates.get(s1_id, set()):
                    all_candidates[s1_id].add(m)
            candidates = sorted(all_candidates.get(s1_id, set()))

            fw_m.writerow([s1_id, ','.join(matches)])
            fw_c.writerow([s1_id, ','.join(candidates)])

    # ── Summary ───────────────────────────────────────────────────────────────
    total_s1      = len(s1_data)
    total_matched = sum(1 for v in all_matches.values() if v)
    total_singletons = total_s1 - total_matched
    total_pred_matches = sum(len(v) for v in all_matches.values())

    print(f"\n{'='*60}")
    print(f"M-RESOLVER V3 PIPELINE COMPLETE")
    print(f"{'='*60}")
    print(f"Total S1 entities:      {total_s1:,}")
    print(f"Entities with matches:  {total_matched:,}")
    print(f"Predicted singletons:   {total_singletons:,} ({total_singletons/total_s1*100:.2f}%)")
    print(f"Total matches predicted:{total_pred_matches:,}")
    print(f"Avg matches per entity: {total_pred_matches/total_s1:.2f}")
    print(f"Total comparisons:      {total_comparisons:,}")
    print(f"Write time:             {time.time()-write_t:.1f}s")
    print(f"Total wall-clock time:  {time.time()-t0:.1f}s")
    print(f"Output: {match_out}")
    print(f"Output: {cands_out}")
    print(f"{'='*60}")


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--test-dir',    default='student_resource/dataset/test')
    parser.add_argument('--output-dir',  default='student_resource/output')
    args = parser.parse_args()
    run_pipeline_v3(args.test_dir, args.output_dir)
